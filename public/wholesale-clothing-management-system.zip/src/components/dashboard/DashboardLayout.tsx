/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useWholesale } from '../../context/WholesaleContext';
import { formatNpr } from '../../i18n';
import {
  LayoutDashboard,
  Package,
  Users,
  ShoppingCart,
  CreditCard,
  FileSpreadsheet,
  Truck,
  BookOpen,
  Network,
  History,
  Code2,
  CheckCircle,
  XCircle,
  Plus,
  Printer,
  ShieldAlert,
  ArrowUpRight,
  TrendingUp,
} from 'lucide-react';
import { CustomerCategory, AccountStatus, OrderStatus, Product, ROLE_PERMISSIONS } from '../../types';

export const DashboardLayout: React.FC = () => {
  const {
    currentRole,
    activeStaffName,
    companySettings,
    products,
    adjustStock,
    customers,
    updateCustomerCategory,
    updateCustomerStatus,
    orders,
    updateOrderStatus,
    paymentClaims,
    verifyPayment,
    invoices,
    generateInvoice,
    dispatchRecords,
    createDispatchRecord,
    updateDispatchStatus,
    ledger,
    addLedgerEntry,
    reverseLedgerEntry,
    distributors,
    auditLogs,
  } = useWholesale();

  const [activeTab, setActiveTab] = useState<string>('overview');
  const perms = ROLE_PERMISSIONS[currentRole];

  // Stock adjustment modal/state
  const [adjustModalProduct, setAdjustModalProduct] = useState<Product | null>(null);
  const [stockDelta, setStockDelta] = useState<number>(10);
  const [stockReason, setStockReason] = useState<string>('New inbound container received at warehouse');

  // New Ledger Entry State
  const [showLedgerModal, setShowLedgerModal] = useState(false);
  const [ledgerForm, setLedgerForm] = useState({
    entryType: 'expense' as const,
    amountNpr: 25000,
    accountCategory: 'Operational Expense',
    referenceNumber: 'VOUCHER-001',
    partyName: 'Supplier / Service Provider',
    transactionDate: new Date().toISOString().split('T')[0],
    notes: 'Warehouse packaging materials and tape cartons',
  });

  // Dispatch modal state
  const [dispatchModalOrder, setDispatchModalOrder] = useState<any | null>(null);
  const [dispatchForm, setDispatchForm] = useState({
    transporterName: 'Sundar Yatayat Cargo Services',
    trackingOrBiltyNumber: 'BILTY-KTM-9921',
    driverPhone: '+977-9851000000',
    totalCartons: 5,
    destinationAddress: '',
  });

  // Selected invoice for printable view
  const [selectedInvoice, setSelectedInvoice] = useState<any | null>(null);

  // Computed metrics
  const totalWholesaleRevenue = orders
    .filter((o) => o.status === 'paid' || o.status === 'dispatched' || o.status === 'delivered')
    .reduce((sum, o) => sum + o.totalNpr, 0);

  const pendingOrdersCount = orders.filter((o) => o.status === 'submitted' || o.status === 'under_review').length;
  const pendingPaymentsCount = paymentClaims.filter((c) => c.verificationStatus === 'pending').length;
  const pendingCustomersCount = customers.filter((c) => c.status === 'pending').length;
  const lowStockCount = products.filter((p) => p.availableStock < 50).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Top Staff Identity Banner */}
      <div className="bg-slate-900 text-white rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-400">
            <span>OFFICE & OPERATIONS MANAGEMENT CONSOLE</span>
            <span aria-hidden="true">·</span>
            <span>Kathmandu Operations Hub</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold mt-1 tracking-tight">
            Wholesale Operations Desk
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Logged in as: <strong className="text-white">{activeStaffName}</strong> ({currentRole.toUpperCase()})
          </p>
        </div>

        {/* Permission Badges */}
        <div className="flex flex-wrap gap-2 text-[11px] font-mono">
          <span className={`px-2 py-1 rounded border ${perms.canApproveOrders ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300' : 'bg-slate-800 border-slate-700 text-slate-500'}`}>
            Orders: {perms.canApproveOrders ? 'APPROVER' : 'VIEW ONLY'}
          </span>
          <span className={`px-2 py-1 rounded border ${perms.canVerifyPayments ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300' : 'bg-slate-800 border-slate-700 text-slate-500'}`}>
            Payments: {perms.canVerifyPayments ? 'AUDITOR' : 'NO ACCESS'}
          </span>
          <span className={`px-2 py-1 rounded border ${perms.canViewLedger ? 'bg-sky-950/60 border-sky-500/40 text-sky-300' : 'bg-slate-800 border-slate-700 text-slate-500'}`}>
            Ledger: {perms.canViewLedger ? 'RESTRICTED ACCESS' : 'LOCKED'}
          </span>
        </div>
      </div>

      {/* Dashboard Sub-navigation Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto pb-2 border-b border-slate-200">
        {[
          { id: 'overview', label: 'Overview', icon: LayoutDashboard },
          { id: 'orders', label: `Orders (${orders.length})`, icon: ShoppingCart },
          { id: 'payments', label: `Payments (${pendingPaymentsCount} Pending)`, icon: CreditCard },
          { id: 'inventory', label: 'Inventory & Stock', icon: Package },
          { id: 'customers', label: `Customers (${pendingCustomersCount} Review)`, icon: Users },
          { id: 'invoices', label: 'Tax Invoices', icon: FileSpreadsheet },
          { id: 'dispatch', label: 'Logistics & Dispatch', icon: Truck },
          { id: 'ledger', label: 'Private Ledger', icon: BookOpen },
          { id: 'distributors', label: 'Distributor Network', icon: Network },
          { id: 'audit', label: 'System Audit Log', icon: History },
          { id: 'blueprint', label: 'Phase 0 Blueprint & Architecture', icon: Code2 },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 py-2 text-xs font-semibold rounded-lg flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                activeTab === tab.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* 1. OVERVIEW TAB */}
      {/* ========================================================================= */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Key Metric Counters */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
              <span className="text-xs font-medium text-slate-500 block">Total Realized Revenue</span>
              <span className="text-2xl font-bold font-mono text-slate-900 mt-2 block tabular-nums">
                {formatNpr(totalWholesaleRevenue)}
              </span>
              <span className="text-[11px] text-emerald-700 font-medium mt-1 block">
                From verified paid & dispatched bulk shipments
              </span>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
              <span className="text-xs font-medium text-slate-500 block">Orders Awaiting Review</span>
              <span className="text-2xl font-bold font-mono text-slate-900 mt-2 block tabular-nums">
                {pendingOrdersCount}
              </span>
              <span className="text-[11px] text-amber-700 font-medium mt-1 block">
                Awaiting sales quota & category limit check
              </span>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
              <span className="text-xs font-medium text-slate-500 block">Payment Reconciliations</span>
              <span className="text-2xl font-bold font-mono text-slate-900 mt-2 block tabular-nums">
                {pendingPaymentsCount}
              </span>
              <span className="text-[11px] text-sky-700 font-medium mt-1 block">
                Fonepay QR / Bank voucher claims pending
              </span>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
              <span className="text-xs font-medium text-slate-500 block">Low Stock Inventory Alerts</span>
              <span className="text-2xl font-bold font-mono text-slate-900 mt-2 block tabular-nums">
                {lowStockCount} lines
              </span>
              <span className="text-[11px] text-slate-500 mt-1 block">
                Garments with &lt; 50 packs remaining
              </span>
            </div>
          </div>

          {/* Quick Action Tables: Recent Orders & Payment Claims */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Orders Summary */}
            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-sm font-bold text-slate-900">Recent Wholesale Orders</h3>
                <button
                  onClick={() => setActiveTab('orders')}
                  className="text-xs text-slate-600 hover:text-slate-900 font-semibold"
                >
                  View All &rarr;
                </button>
              </div>
              <div className="space-y-3">
                {orders.slice(0, 4).map((o) => (
                  <div
                    key={o.id}
                    className="p-3 bg-slate-50 rounded-lg border border-slate-100 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-semibold text-slate-900 font-mono">{o.orderNumber}</div>
                      <div className="text-slate-500">{o.businessName}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono font-bold text-slate-900">{formatNpr(o.totalNpr)}</div>
                      <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded bg-white border border-slate-200 inline-block mt-0.5">
                        {o.status.replace('_', ' ')}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Payments Summary */}
            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-sm font-bold text-slate-900">Recent Payment Claims</h3>
                <button
                  onClick={() => setActiveTab('payments')}
                  className="text-xs text-slate-600 hover:text-slate-900 font-semibold"
                >
                  View All &rarr;
                </button>
              </div>
              <div className="space-y-3">
                {paymentClaims.slice(0, 4).map((c) => (
                  <div
                    key={c.id}
                    className="p-3 bg-slate-50 rounded-lg border border-slate-100 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-semibold text-slate-900 font-mono">{c.paymentReference}</div>
                      <div className="text-slate-500">{c.customerBusinessName} ({c.paymentMethod})</div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono font-bold text-slate-900">{formatNpr(c.amountClaimedNpr)}</div>
                      <span className={`text-[10px] font-semibold uppercase px-2 py-0.5 rounded inline-block mt-0.5 ${
                        c.verificationStatus === 'verified'
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          : c.verificationStatus === 'rejected'
                          ? 'bg-rose-50 text-rose-800 border border-rose-200'
                          : 'bg-amber-50 text-amber-800 border border-amber-200'
                      }`}>
                        {c.verificationStatus}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. ORDERS MANAGEMENT TAB */}
      {/* ========================================================================= */}
      {activeTab === 'orders' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">Wholesale Orders Queue</h2>
              <p className="text-xs text-slate-500">
                Authoritative validation: Customers cannot alter order status. Approved orders transition to invoice generation.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold">
                  <th className="py-3 px-4">Order No.</th>
                  <th className="py-3 px-4">Customer Business</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Packs / Garments</th>
                  <th className="py-3 px-4 text-right">Subtotal</th>
                  <th className="py-3 px-4 text-right">Total (VAT Incl.)</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Operational Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {orders.map((o) => {
                  const totalPacks = o.items.reduce((s, i) => s + i.quantityPacks, 0);
                  const totalPcs = o.items.reduce((s, i) => s + i.totalGarments, 0);

                  return (
                    <tr key={o.id} className="hover:bg-slate-50/80">
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">{o.orderNumber}</td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{o.businessName}</div>
                        <div className="text-[11px] text-slate-500">{o.customerName}</div>
                      </td>
                      <td className="py-3 px-4 font-mono font-bold">Tier {o.customerCategory}</td>
                      <td className="py-3 px-4 font-mono">
                        {totalPacks} packs <span className="text-slate-400">({totalPcs} pcs)</span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">{formatNpr(o.subtotalNpr)}</td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                        {formatNpr(o.totalNpr)}
                      </td>
                      <td className="py-3 px-4">
                        <span className={`inline-block px-2.5 py-0.5 rounded text-[10px] font-semibold uppercase ${
                          o.status === 'delivered' || o.status === 'paid'
                            ? 'bg-emerald-100 text-emerald-800'
                            : o.status === 'dispatched'
                            ? 'bg-sky-100 text-sky-800'
                            : o.status === 'rejected' || o.status === 'cancelled'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {o.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right space-x-1">
                        {/* Review / Approval */}
                        {o.status === 'submitted' && perms.canApproveOrders && (
                          <button
                            onClick={() => updateOrderStatus(o.id, 'approved', 'Approved by sales desk review')}
                            className="px-2 py-1 bg-emerald-700 text-white rounded text-[11px] hover:bg-emerald-800 font-medium"
                          >
                            Approve
                          </button>
                        )}

                        {o.status === 'submitted' && perms.canApproveOrders && (
                          <button
                            onClick={() => updateOrderStatus(o.id, 'rejected', 'Stock mismatch or credit hold')}
                            className="px-2 py-1 bg-rose-600 text-white rounded text-[11px] hover:bg-rose-700 font-medium"
                          >
                            Reject
                          </button>
                        )}

                        {/* Invoice Generation */}
                        {perms.canGenerateInvoices && !o.invoiceId && (
                          <button
                            onClick={() => generateInvoice(o.id)}
                            className="px-2 py-1 bg-slate-800 text-white rounded text-[11px] hover:bg-slate-700 font-medium"
                          >
                            Issue Tax Invoice
                          </button>
                        )}

                        {/* Dispatch Entry */}
                        {perms.canManageDispatch && (o.status === 'paid' || o.status === 'approved') && (
                          <button
                            onClick={() => {
                              setDispatchModalOrder(o);
                              setDispatchForm({
                                transporterName: 'Sundar Yatayat Cargo Services',
                                trackingOrBiltyNumber: `BILTY-NP-${Date.now().toString().slice(-4)}`,
                                driverPhone: '+977-9851022334',
                                totalCartons: Math.max(1, Math.ceil(totalPacks / 4)),
                                destinationAddress: o.shippingAddress,
                              });
                            }}
                            className="px-2 py-1 bg-sky-700 text-white rounded text-[11px] hover:bg-sky-800 font-medium"
                          >
                            Dispatch Cargo
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. PAYMENT VERIFICATION TAB */}
      {/* ========================================================================= */}
      {activeTab === 'payments' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-6">
          <div>
            <h2 className="text-base font-bold text-slate-900">Payment Reconciliation Desk</h2>
            <p className="text-xs text-slate-500">
              Strict reconciliation: Proof screenshots/reference numbers submitted by clients must be verified against bank statements before order release.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold">
                  <th className="py-3 px-4">Claim Date</th>
                  <th className="py-3 px-4">Order No.</th>
                  <th className="py-3 px-4">Customer Business</th>
                  <th className="py-3 px-4">Payment Method</th>
                  <th className="py-3 px-4">Reference / TXN ID</th>
                  <th className="py-3 px-4 text-right">Claimed NPR</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Verification Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {paymentClaims.map((claim) => (
                  <tr key={claim.id} className="hover:bg-slate-50/80">
                    <td className="py-3 px-4 font-mono text-slate-500">{claim.paymentDate}</td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">{claim.orderNumber}</td>
                    <td className="py-3 px-4 font-semibold text-slate-900">{claim.customerBusinessName}</td>
                    <td className="py-3 px-4 font-mono uppercase text-slate-600">{claim.paymentMethod}</td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-800">{claim.paymentReference}</td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                      {formatNpr(claim.amountClaimedNpr)}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`inline-block px-2.5 py-0.5 rounded text-[10px] font-semibold uppercase ${
                        claim.verificationStatus === 'verified'
                          ? 'bg-emerald-100 text-emerald-800'
                          : claim.verificationStatus === 'rejected'
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {claim.verificationStatus}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right space-x-1.5">
                      {claim.verificationStatus === 'pending' && perms.canVerifyPayments ? (
                        <>
                          <button
                            onClick={() => verifyPayment(claim.id, 'verified', 'Bank account statement matched')}
                            className="px-2.5 py-1 bg-emerald-700 text-white rounded text-[11px] hover:bg-emerald-800 font-semibold"
                          >
                            Verify & Mark Paid
                          </button>
                          <button
                            onClick={() => verifyPayment(claim.id, 'rejected', 'Reference not found in bank statement')}
                            className="px-2 py-1 bg-rose-600 text-white rounded text-[11px] hover:bg-rose-700 font-medium"
                          >
                            Reject
                          </button>
                        </>
                      ) : (
                        <span className="text-[11px] text-slate-400 font-mono">
                          {claim.verifiedBy ? `By: ${claim.verifiedBy}` : 'Reconciled'}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. INVENTORY & STOCK MANAGEMENT TAB */}
      {/* ========================================================================= */}
      {activeTab === 'inventory' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">Garment Product & Stock Management</h2>
              <p className="text-xs text-slate-500">
                Atomic inventory tracking. Cost price is strictly concealed from non-accounting staff.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold">
                  <th className="py-3 px-4">SKU</th>
                  <th className="py-3 px-4">Garment Line</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Fabric / GSM</th>
                  <th className="py-3 px-4">MOQ</th>
                  <th className="py-3 px-4 text-right">Wholesale Rate</th>
                  {perms.canViewCostPrices && <th className="py-3 px-4 text-right text-amber-700">Cost Price (Private)</th>}
                  <th className="py-3 px-4 text-right">Available Stock</th>
                  <th className="py-3 px-4 text-right">Stock Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {products.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/80">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">{p.sku}</td>
                    <td className="py-3 px-4 font-semibold text-slate-900">{p.name}</td>
                    <td className="py-3 px-4 text-slate-600">{p.category}</td>
                    <td className="py-3 px-4 text-slate-500">{p.fabricComposition}</td>
                    <td className="py-3 px-4 font-mono">{p.minOrderQuantity} packs</td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                      {formatNpr(p.wholesalePriceNpr)}
                    </td>
                    {perms.canViewCostPrices && (
                      <td className="py-3 px-4 text-right font-mono font-bold text-amber-700 tabular-nums">
                        {p.costPriceNpr ? formatNpr(p.costPriceNpr) : '—'}
                      </td>
                    )}
                    <td className="py-3 px-4 text-right font-mono font-bold tabular-nums">
                      <span className={p.availableStock < 50 ? 'text-rose-600' : 'text-emerald-700'}>
                        {p.availableStock} packs
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      {perms.canManageInventory && (
                        <button
                          onClick={() => {
                            setAdjustModalProduct(p);
                            setStockDelta(20);
                            setStockReason('Mill direct bulk shipment arrival');
                          }}
                          className="px-2.5 py-1 bg-slate-900 text-white rounded text-[11px] hover:bg-slate-800 font-medium"
                        >
                          Adjust Stock
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. CUSTOMER ACCOUNTS & LICENSES TAB */}
      {/* ========================================================================= */}
      {activeTab === 'customers' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-6">
          <div>
            <h2 className="text-base font-bold text-slate-900">Wholesale Customer Directory & Approvals</h2>
            <p className="text-xs text-slate-500">
              Only authorized staff can assign credit categories (C / B / F) or approve self-registered buyers.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold">
                  <th className="py-3 px-4">Business Name</th>
                  <th className="py-3 px-4">Proprietor</th>
                  <th className="py-3 px-4">Phone / City</th>
                  <th className="py-3 px-4">PAN / VAT & License</th>
                  <th className="py-3 px-4">Tier Category</th>
                  <th className="py-3 px-4">Account Status</th>
                  <th className="py-3 px-4 text-right">Approval & Category Controls</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {customers.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/80">
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">{c.businessName}</div>
                      <div className="text-[11px] text-slate-500 font-mono">{c.email}</div>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-900">{c.name}</td>
                    <td className="py-3 px-4">
                      <div className="font-mono">{c.phone}</div>
                      <div className="text-[11px] text-slate-500">{c.businessAddress}</div>
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px]">
                      <div>PAN: {c.panVatNumber || 'Pending'}</div>
                      <div className="text-slate-400">Lic: {c.licenseNumber || 'Pending'}</div>
                    </td>
                    <td className="py-3 px-4 font-mono font-bold">
                      <span className="px-2 py-0.5 rounded bg-slate-100 border border-slate-200">
                        Tier {c.category} ({formatNpr(companySettings.categoryLimits[c.category])})
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`inline-block px-2.5 py-0.5 rounded text-[10px] font-semibold uppercase ${
                        c.status === 'active'
                          ? 'bg-emerald-100 text-emerald-800'
                          : c.status === 'pending'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}>
                        {c.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right space-x-1.5">
                      {perms.canApproveCustomers && c.status === 'pending' && (
                        <button
                          onClick={() => updateCustomerStatus(c.id, 'active', 'Verified trade registration and PAN')}
                          className="px-2 py-1 bg-emerald-700 text-white rounded text-[11px] hover:bg-emerald-800 font-semibold"
                        >
                          Approve Account
                        </button>
                      )}

                      {perms.canChangeCustomerCategory && (
                        <select
                          value={c.category}
                          onChange={(e) => updateCustomerCategory(c.id, e.target.value as CustomerCategory)}
                          className="bg-white border border-slate-300 rounded px-2 py-1 text-[11px] font-semibold text-slate-800 cursor-pointer"
                        >
                          <option value="C">Set Tier C (200k)</option>
                          <option value="B">Set Tier B (75k)</option>
                          <option value="F">Set Tier F (35k)</option>
                        </select>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. TAX INVOICES TAB */}
      {/* ========================================================================= */}
      {activeTab === 'invoices' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-base font-bold text-slate-900">Tax Invoices (Nepal IRD Compliant)</h2>
              <p className="text-xs text-slate-500">
                Official invoices with itemized VAT calculations and permanent unique sequential numbering.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold">
                  <th className="py-3 px-4">Invoice No.</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Order Ref</th>
                  <th className="py-3 px-4">Customer Business</th>
                  <th className="py-3 px-4">PAN / VAT</th>
                  <th className="py-3 px-4 text-right">Taxable Subtotal</th>
                  <th className="py-3 px-4 text-right">13% VAT</th>
                  <th className="py-3 px-4 text-right">Total Payable</th>
                  <th className="py-3 px-4 text-right">Printable Invoice</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoices.map((inv) => (
                  <tr key={inv.id} className="hover:bg-slate-50/80">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">{inv.invoiceNumber}</td>
                    <td className="py-3 px-4 font-mono text-slate-500">{inv.issueDate}</td>
                    <td className="py-3 px-4 font-mono font-semibold text-slate-800">{inv.orderNumber}</td>
                    <td className="py-3 px-4 font-semibold text-slate-900">{inv.customerBusinessName}</td>
                    <td className="py-3 px-4 font-mono text-slate-600">{inv.panVatNumber}</td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">{formatNpr(inv.subtotalNpr)}</td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">{formatNpr(inv.vatAmountNpr)}</td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                      {formatNpr(inv.totalNpr)}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => setSelectedInvoice(inv)}
                        className="px-2.5 py-1 bg-slate-900 text-white rounded text-[11px] hover:bg-slate-800 font-semibold inline-flex items-center gap-1"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>View Invoice</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 7. LOGISTICS & DISPATCH TAB */}
      {/* ========================================================================= */}
      {activeTab === 'dispatch' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-6">
          <div>
            <h2 className="text-base font-bold text-slate-900">Inter-District Logistics & Bilty Queue</h2>
            <p className="text-xs text-slate-500">
              Track parcel cartons dispatched via regional freight networks (Sundar Yatayat, City Cargo, Narayani Freight).
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold">
                  <th className="py-3 px-4">Bilty Receipt No.</th>
                  <th className="py-3 px-4">Order Ref</th>
                  <th className="py-3 px-4">Transporter Name</th>
                  <th className="py-3 px-4">Destination Counter</th>
                  <th className="py-3 px-4 font-mono">Cartons</th>
                  <th className="py-3 px-4">Dispatch Date</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Logistics Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {dispatchRecords.map((disp) => (
                  <tr key={disp.id} className="hover:bg-slate-50/80">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">{disp.trackingOrBiltyNumber}</td>
                    <td className="py-3 px-4 font-mono font-semibold text-slate-800">{disp.orderNumber}</td>
                    <td className="py-3 px-4 font-medium text-slate-900">{disp.transporterName}</td>
                    <td className="py-3 px-4 text-slate-600">{disp.destinationAddress}</td>
                    <td className="py-3 px-4 font-mono font-bold">{disp.totalCartons} cartons</td>
                    <td className="py-3 px-4 font-mono text-slate-500">{disp.dispatchDate}</td>
                    <td className="py-3 px-4">
                      <span className={`inline-block px-2.5 py-0.5 rounded text-[10px] font-semibold uppercase ${
                        disp.status === 'delivered'
                          ? 'bg-emerald-100 text-emerald-800'
                          : disp.status === 'in_transit'
                          ? 'bg-sky-100 text-sky-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {disp.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      {perms.canManageDispatch && disp.status === 'in_transit' && (
                        <button
                          onClick={() => updateDispatchStatus(disp.id, 'delivered')}
                          className="px-2 py-1 bg-emerald-700 text-white rounded text-[11px] hover:bg-emerald-800 font-semibold"
                        >
                          Mark Delivered
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 8. RESTRICTED ACCOUNTING LEDGER TAB */}
      {/* ========================================================================= */}
      {activeTab === 'ledger' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-900">Restricted Internal Accounting Ledger</h2>
                <span className="text-[10px] font-bold uppercase bg-amber-100 text-amber-900 border border-amber-300 px-2 py-0.5 rounded">
                  Confidential
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Internal accounting records, supplier payables, fabric procurement costs, and receivables. Strictly isolated from customer queries.
              </p>
            </div>

            {perms.canModifyLedger && (
              <button
                onClick={() => setShowLedgerModal(true)}
                className="px-3 py-1.5 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 flex items-center gap-1.5 self-start sm:self-auto"
              >
                <Plus className="w-4 h-4" />
                <span>Add Ledger Entry</span>
              </button>
            )}
          </div>

          {!perms.canViewLedger ? (
            <div className="p-8 text-center bg-slate-50 border border-slate-200 rounded-xl">
              <ShieldAlert className="w-10 h-10 text-rose-500 mx-auto mb-2" />
              <h3 className="text-sm font-bold text-slate-900">Access Denied</h3>
              <p className="text-xs text-slate-500 mt-1">
                Your current role ({currentRole}) is not authorized to inspect the private business ledger.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold">
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Type</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4">Party / Vendor</th>
                    <th className="py-3 px-4">Ref Voucher</th>
                    <th className="py-3 px-4 text-right">Amount (NPR)</th>
                    <th className="py-3 px-4">Auditor Note</th>
                    <th className="py-3 px-4 text-right">Control</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {ledger.map((entry) => (
                    <tr key={entry.id} className={`hover:bg-slate-50/80 ${entry.isReversed ? 'opacity-50 line-through' : ''}`}>
                      <td className="py-3 px-4 font-mono text-slate-500">{entry.transactionDate}</td>
                      <td className="py-3 px-4 font-semibold uppercase font-mono">
                        <span className={`px-2 py-0.5 rounded text-[10px] ${
                          entry.entryType === 'income'
                            ? 'bg-emerald-100 text-emerald-800'
                            : entry.entryType === 'expense'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-sky-100 text-sky-800'
                        }`}>
                          {entry.entryType.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-900">{entry.accountCategory}</td>
                      <td className="py-3 px-4 text-slate-700">{entry.partyName}</td>
                      <td className="py-3 px-4 font-mono text-slate-500">{entry.referenceNumber}</td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                        {formatNpr(entry.amountNpr)}
                      </td>
                      <td className="py-3 px-4 text-slate-600 max-w-xs truncate">{entry.notes}</td>
                      <td className="py-3 px-4 text-right">
                        {perms.canModifyLedger && !entry.isReversed && (
                          <button
                            onClick={() => reverseLedgerEntry(entry.id, 'Authorized reversal by Chief Accountant')}
                            className="text-rose-600 hover:text-rose-800 text-[11px] font-semibold underline"
                          >
                            Reverse Entry
                          </button>
                        )}
                        {entry.isReversed && (
                          <span className="text-[10px] text-rose-600 font-mono">Reversed</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 9. DISTRIBUTOR NETWORK TAB */}
      {/* ========================================================================= */}
      {activeTab === 'distributors' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-6">
          <div>
            <h2 className="text-base font-bold text-slate-900">Distributor Member Hierarchy</h2>
            <p className="text-xs text-slate-500">
              Regional distributor nodes across Nepal. Internal hierarchy structures prevent circular referencing.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {distributors.map((dist) => (
              <div key={dist.id} className="border border-slate-200 rounded-xl p-5 bg-slate-50/50 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center text-xs text-slate-500 mb-2">
                    <span className="font-mono font-bold text-slate-900">{dist.code}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-slate-200 font-mono">
                      Level {dist.level} Partner
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900">{dist.businessName}</h3>
                  <div className="text-xs text-slate-600 mt-1">{dist.fullName}</div>
                  <div className="text-xs text-slate-500 mt-2 font-mono">Territory: {dist.territory}</div>
                </div>

                <div className="mt-5 pt-4 border-t border-slate-200 space-y-1.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Allocated Bulk Orders:</span>
                    <span className="font-mono font-bold text-slate-900">{dist.totalOrdersAllocated}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Total Volume:</span>
                    <span className="font-mono font-bold text-slate-900">{formatNpr(dist.totalVolumeNpr)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Contact:</span>
                    <span className="font-mono text-slate-700">{dist.contactPhone}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 10. SYSTEM AUDIT LOG TAB */}
      {/* ========================================================================= */}
      {activeTab === 'audit' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-6">
          <div>
            <h2 className="text-base font-bold text-slate-900">System Security Audit Log</h2>
            <p className="text-xs text-slate-500">
              Immutable audit trail recording state changes, customer approvals, payment verifications, and stock adjustments.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold">
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4">Action</th>
                  <th className="py-3 px-4">Actor</th>
                  <th className="py-3 px-4">Role</th>
                  <th className="py-3 px-4">Entity</th>
                  <th className="py-3 px-4">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/80">
                    <td className="py-3 px-4 text-slate-500 whitespace-nowrap">{log.timestamp.slice(0, 19)}</td>
                    <td className="py-3 px-4 font-bold text-slate-900">{log.action}</td>
                    <td className="py-3 px-4 text-slate-700">{log.actorEmail}</td>
                    <td className="py-3 px-4 uppercase text-[10px]">{log.actorRole}</td>
                    <td className="py-3 px-4 text-slate-500">{log.entityType} ({log.entityId})</td>
                    <td className="py-3 px-4 font-sans text-slate-700">{log.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 11. PHASE 0 BLUEPRINT & ARCHITECTURE SPECIFICATION TAB */}
      {/* ========================================================================= */}
      {activeTab === 'blueprint' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-8">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-800 bg-amber-100 px-2.5 py-1 rounded">
              <span>PHASE 0 ARCHITECTURAL SPECIFICATION & VERIFICATION</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 mt-2">
              System Architecture, Route Map & Security Plan
            </h2>
            <p className="mt-1 text-sm text-slate-600 leading-relaxed">
              Formal inspection results, route manifest, entity relations, permissions matrix, and step-by-step phased execution plan as mandated by the master prompt.
            </p>
          </div>

          {/* Environment Inspection Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="text-slate-500 font-semibold block">Frontend Environment</span>
              <span className="text-sm font-bold text-slate-900 mt-1 block">React 19 + TypeScript + Vite 8</span>
              <p className="text-slate-600 mt-1">Tailwind CSS v4 with Plus Jakarta Sans & JetBrains Mono tabular-nums.</p>
            </div>
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="text-slate-500 font-semibold block">Backend & Database Target</span>
              <span className="text-sm font-bold text-slate-900 mt-1 block">Cloud Firestore + Firebase Auth</span>
              <p className="text-slate-600 mt-1">Zero-Trust ABAC security rules with split PII collections and server timestamp integrity.</p>
            </div>
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="text-slate-500 font-semibold block">Currency & Localization</span>
              <span className="text-sm font-bold text-slate-900 mt-1 block">NPR (Nepalese Rupees) + i18n</span>
              <p className="text-slate-600 mt-1">English primary with full Nepali translations dictionary in place.</p>
            </div>
          </div>

          {/* Permissions Matrix */}
          <div>
            <h3 className="text-sm font-bold text-slate-900 mb-3">Role-Based Access Control (RBAC) Permissions Matrix</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border border-slate-200">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-bold uppercase">
                    <th className="p-2 border">Permission Capability</th>
                    <th className="p-2 border text-center">Owner</th>
                    <th className="p-2 border text-center">Admin</th>
                    <th className="p-2 border text-center">Inventory</th>
                    <th className="p-2 border text-center">Sales</th>
                    <th className="p-2 border text-center">Accounts</th>
                    <th className="p-2 border text-center">Dispatch</th>
                    <th className="p-2 border text-center">Customer</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  <tr>
                    <td className="p-2 border font-sans font-medium">Manage Products & Garment SKUs</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                  </tr>
                  <tr>
                    <td className="p-2 border font-sans font-medium">View Confidential Cost Prices</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                  </tr>
                  <tr>
                    <td className="p-2 border font-sans font-medium">Approve Customers & Upgrades</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                  </tr>
                  <tr>
                    <td className="p-2 border font-sans font-medium">Review & Approve Orders</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                  </tr>
                  <tr>
                    <td className="p-2 border font-sans font-medium">Verify Payments (QR / Bank)</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                  </tr>
                  <tr>
                    <td className="p-2 border font-sans font-medium">Generate Tax Invoices</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                  </tr>
                  <tr>
                    <td className="p-2 border font-sans font-medium">Access Restricted Ledger</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-emerald-600 font-bold">YES</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                    <td className="p-2 border text-center text-slate-300">NO</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Phased Implementation Roadmap */}
          <div>
            <h3 className="text-sm font-bold text-slate-900 mb-3">Project Phased Roadmap</h3>
            <div className="space-y-3 text-xs">
              <div className="p-3.5 bg-emerald-50 border border-emerald-300 rounded-lg flex items-start gap-3">
                <CheckCircle className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-emerald-900">Phase 0 — Inspect & Plan (CURRENT)</strong>
                  <p className="text-emerald-800 mt-0.5">
                    Completed environment inspection, types/schema specification, NPR currency integration, i18n structure, permissions matrix, and stable interactive UI harness.
                  </p>
                </div>
              </div>

              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg flex items-start gap-3">
                <div className="w-4 h-4 rounded-full border-2 border-slate-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900">Phase 1 — Stable Frontend Foundation</strong>
                  <p className="text-slate-600 mt-0.5">
                    Polish public pages (Home, Catalogue, Details, About, News, Plans, Contact, Modals) with responsive layout and zero dead clicks.
                  </p>
                </div>
              </div>

              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg flex items-start gap-3">
                <div className="w-4 h-4 rounded-full border-2 border-slate-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900">Phase 2 — Authentication & Firestore Backend Integration</strong>
                  <p className="text-slate-600 mt-0.5">
                    Configure Firebase Authentication, Cloud Firestore schemas, zero-trust rules, and owner bootstrap.
                  </p>
                </div>
              </div>

              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg flex items-start gap-3">
                <div className="w-4 h-4 rounded-full border-2 border-slate-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900">Phase 3 — Products & Inventory Movements</strong>
                  <p className="text-slate-600 mt-0.5">
                    Atomic inventory deduction, MOQ pack enforcement, and fabric specs.
                  </p>
                </div>
              </div>

              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg flex items-start gap-3">
                <div className="w-4 h-4 rounded-full border-2 border-slate-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900">Phase 4 — Customers & Category Order Limits (C/B/F)</strong>
                  <p className="text-slate-600 mt-0.5">
                    Backend order limit enforcement (NPR 200k, 75k, 35k), license document protection, and order lifecycles.
                  </p>
                </div>
              </div>

              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg flex items-start gap-3">
                <div className="w-4 h-4 rounded-full border-2 border-slate-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900">Phase 5 — Payment QR, Invoices & Dispatch</strong>
                  <p className="text-slate-600 mt-0.5">
                    Reconciliation workflow, printable IRD tax invoices, and cargo tracking bilty records.
                  </p>
                </div>
              </div>

              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg flex items-start gap-3">
                <div className="w-4 h-4 rounded-full border-2 border-slate-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900">Phase 6 & 7 — Private Accounting Ledger & Final QA</strong>
                  <p className="text-slate-600 mt-0.5">
                    Restricted ledger audits, distributor hierarchy, cross-role security testing, and production checklist.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: STOCK ADJUSTMENT */}
      {/* ========================================================================= */}
      {adjustModalProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">Adjust Inventory Stock</h3>
            <div className="text-xs text-slate-600">
              Product: <strong>{adjustModalProduct.name}</strong> ({adjustModalProduct.sku})
            </div>
            <div className="text-xs text-slate-500 font-mono">
              Current Available: {adjustModalProduct.availableStock} packs
            </div>

            <div className="space-y-3 pt-2">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Packs to Add (+) or Deduct (-)
                </label>
                <input
                  type="number"
                  value={stockDelta}
                  onChange={(e) => setStockDelta(parseInt(e.target.value) || 0)}
                  className="w-full bg-white border border-slate-300 rounded px-3 py-1.5 text-xs font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Reason for Adjustment *</label>
                <input
                  type="text"
                  required
                  value={stockReason}
                  onChange={(e) => setStockReason(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setAdjustModalProduct(null)}
                  className="px-3 py-1.5 border border-slate-300 rounded text-xs text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    adjustStock(adjustModalProduct.id, stockDelta, stockReason);
                    setAdjustModalProduct(null);
                  }}
                  className="px-4 py-1.5 bg-slate-900 text-white rounded text-xs font-semibold hover:bg-slate-800"
                >
                  Confirm Adjustment
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: DISPATCH CARGO */}
      {/* ========================================================================= */}
      {dispatchModalOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">Create Cargo Dispatch Record</h3>
            <div className="text-xs text-slate-600">
              Order: <strong>{dispatchModalOrder.orderNumber}</strong> ({dispatchModalOrder.businessName})
            </div>

            <div className="space-y-3 pt-2 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Transporter / Freight Carrier *</label>
                <input
                  type="text"
                  required
                  value={dispatchForm.transporterName}
                  onChange={(e) => setDispatchForm({ ...dispatchForm, transporterName: e.target.value })}
                  placeholder="e.g. Sundar Yatayat Cargo Services"
                  className="w-full bg-white border border-slate-300 rounded px-3 py-1.5"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Bilty Receipt No. *</label>
                  <input
                    type="text"
                    required
                    value={dispatchForm.trackingOrBiltyNumber}
                    onChange={(e) => setDispatchForm({ ...dispatchForm, trackingOrBiltyNumber: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded px-3 py-1.5 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Total Cartons *</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={dispatchForm.totalCartons}
                    onChange={(e) => setDispatchForm({ ...dispatchForm, totalCartons: parseInt(e.target.value) || 1 })}
                    className="w-full bg-white border border-slate-300 rounded px-3 py-1.5 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Destination Address *</label>
                <input
                  type="text"
                  required
                  value={dispatchForm.destinationAddress}
                  onChange={(e) => setDispatchForm({ ...dispatchForm, destinationAddress: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded px-3 py-1.5"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setDispatchModalOrder(null)}
                  className="px-3 py-1.5 border border-slate-300 rounded text-xs text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    createDispatchRecord({
                      orderId: dispatchModalOrder.id,
                      orderNumber: dispatchModalOrder.orderNumber,
                      invoiceId: dispatchModalOrder.invoiceId,
                      customerBusinessName: dispatchModalOrder.businessName,
                      destinationAddress: dispatchForm.destinationAddress,
                      transporterName: dispatchForm.transporterName,
                      trackingOrBiltyNumber: dispatchForm.trackingOrBiltyNumber,
                      totalCartons: dispatchForm.totalCartons,
                      dispatchDate: new Date().toISOString().split('T')[0],
                      status: 'in_transit',
                      dispatchedBy: activeStaffName,
                    });
                    setDispatchModalOrder(null);
                  }}
                  className="px-4 py-1.5 bg-slate-900 text-white rounded text-xs font-semibold hover:bg-slate-800"
                >
                  Confirm Dispatch
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: ADD LEDGER ENTRY */}
      {/* ========================================================================= */}
      {showLedgerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">Record Internal Ledger Entry</h3>
            
            <form
              onSubmit={(e) => {
                e.preventDefault();
                addLedgerEntry({
                  entryType: ledgerForm.entryType,
                  amountNpr: ledgerForm.amountNpr,
                  accountCategory: ledgerForm.accountCategory,
                  referenceNumber: ledgerForm.referenceNumber,
                  partyName: ledgerForm.partyName,
                  transactionDate: ledgerForm.transactionDate,
                  recordedBy: activeStaffName,
                  notes: ledgerForm.notes,
                });
                setShowLedgerModal(false);
              }}
              className="space-y-3 text-xs"
            >
              <div>
                <label className="block font-medium text-slate-700 mb-1">Entry Classification</label>
                <select
                  value={ledgerForm.entryType}
                  onChange={(e) => setLedgerForm({ ...ledgerForm, entryType: e.target.value as any })}
                  className="w-full bg-white border border-slate-300 rounded px-3 py-1.5 cursor-pointer font-semibold"
                >
                  <option value="expense">Expense (Operational / Mill Advance)</option>
                  <option value="income">Income (Wholesale Revenue)</option>
                  <option value="customer_receivable">Customer Receivable</option>
                  <option value="supplier_payable">Supplier Payable</option>
                  <option value="adjustment">Internal Audit Adjustment</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Amount (NPR) *</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={ledgerForm.amountNpr}
                    onChange={(e) => setLedgerForm({ ...ledgerForm, amountNpr: parseInt(e.target.value) || 0 })}
                    className="w-full bg-white border border-slate-300 rounded px-3 py-1.5 font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Transaction Date *</label>
                  <input
                    type="date"
                    required
                    value={ledgerForm.transactionDate}
                    onChange={(e) => setLedgerForm({ ...ledgerForm, transactionDate: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded px-3 py-1.5 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Account Category *</label>
                <input
                  type="text"
                  required
                  value={ledgerForm.accountCategory}
                  onChange={(e) => setLedgerForm({ ...ledgerForm, accountCategory: e.target.value })}
                  placeholder="e.g. Fabric Procurement / Freight"
                  className="w-full bg-white border border-slate-300 rounded px-3 py-1.5"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Reference No. / Bilty *</label>
                  <input
                    type="text"
                    required
                    value={ledgerForm.referenceNumber}
                    onChange={(e) => setLedgerForm({ ...ledgerForm, referenceNumber: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded px-3 py-1.5 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Party / Vendor Name *</label>
                  <input
                    type="text"
                    required
                    value={ledgerForm.partyName}
                    onChange={(e) => setLedgerForm({ ...ledgerForm, partyName: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded px-3 py-1.5"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Auditor Notes</label>
                <textarea
                  rows={2}
                  value={ledgerForm.notes}
                  onChange={(e) => setLedgerForm({ ...ledgerForm, notes: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded px-3 py-1.5"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowLedgerModal(false)}
                  className="px-3 py-1.5 border border-slate-300 rounded text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-slate-900 text-white rounded font-semibold hover:bg-slate-800"
                >
                  Save to Restricted Ledger
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: PRINTABLE TAX INVOICE */}
      {/* ========================================================================= */}
      {selectedInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-8 space-y-6">
            <div className="flex justify-between items-start border-b border-slate-200 pb-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Government of Nepal · Inland Revenue Department
                </span>
                <h2 className="text-xl font-bold text-slate-900 mt-1">TAX INVOICE / कर बीजक</h2>
                <div className="text-xs text-slate-600 mt-1">
                  <strong>{companySettings.legalEntityName}</strong>
                  <div>PAN / VAT No: <strong className="font-mono">{companySettings.panVatNumber}</strong></div>
                  <div>{companySettings.registeredAddress}</div>
                </div>
              </div>
              <div className="text-right text-xs">
                <div className="font-mono font-bold text-sm text-slate-900">
                  {selectedInvoice.invoiceNumber}
                </div>
                <div className="text-slate-500 mt-1">Date: {selectedInvoice.issueDate}</div>
                <div className="text-slate-500">Order: {selectedInvoice.orderNumber}</div>
                <div className="mt-2">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                    selectedInvoice.paymentStatus === 'paid' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    Payment: {selectedInvoice.paymentStatus}
                  </span>
                </div>
              </div>
            </div>

            {/* Buyer Details */}
            <div className="bg-slate-50 p-4 rounded-xl text-xs space-y-1">
              <div className="text-slate-500 font-semibold uppercase tracking-wider text-[10px]">
                Buyer Details / खरिदकर्ताको विवरण
              </div>
              <div className="font-bold text-slate-900 text-sm">{selectedInvoice.customerBusinessName}</div>
              <div className="text-slate-700">Proprietor: {selectedInvoice.customerName}</div>
              <div className="text-slate-700">PAN / VAT: <strong className="font-mono">{selectedInvoice.panVatNumber}</strong></div>
              <div className="text-slate-500">Delivery Address: {selectedInvoice.customerAddress}</div>
            </div>

            {/* Line Items */}
            <table className="w-full text-xs text-left border-collapse border border-slate-200">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-semibold uppercase">
                  <th className="p-2 border">SN</th>
                  <th className="p-2 border">Garment Description</th>
                  <th className="p-2 border font-mono">Packs</th>
                  <th className="p-2 border text-right">Unit Rate (NPR)</th>
                  <th className="p-2 border text-right">Taxable Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {selectedInvoice.items.map((item: any, idx: number) => (
                  <tr key={idx}>
                    <td className="p-2 border text-slate-500">{idx + 1}</td>
                    <td className="p-2 border font-sans font-medium text-slate-900">
                      {item.productName} ({item.totalGarments} pcs)
                    </td>
                    <td className="p-2 border">{item.quantityPacks}</td>
                    <td className="p-2 border text-right tabular-nums">{formatNpr(item.unitPriceNpr)}</td>
                    <td className="p-2 border text-right font-bold tabular-nums">{formatNpr(item.lineTotalNpr)}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Totals */}
            <div className="flex justify-end text-xs">
              <div className="w-64 space-y-1.5 font-mono">
                <div className="flex justify-between text-slate-600">
                  <span>Taxable Subtotal:</span>
                  <span className="tabular-nums font-semibold">{formatNpr(selectedInvoice.subtotalNpr)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>VAT ({selectedInvoice.vatRatePercent}%):</span>
                  <span className="tabular-nums font-semibold">{formatNpr(selectedInvoice.vatAmountNpr)}</span>
                </div>
                <div className="pt-2 border-t border-slate-300 flex justify-between text-sm font-bold text-slate-900">
                  <span>Grand Total Payable:</span>
                  <span className="tabular-nums text-base">{formatNpr(selectedInvoice.totalNpr)}</span>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 flex justify-between items-center text-xs">
              <div className="text-slate-400">
                Generated by: {selectedInvoice.generatedBy}
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3 py-1.5 border border-slate-300 rounded text-slate-700 hover:bg-slate-50 font-medium"
                >
                  Print Invoice
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedInvoice(null)}
                  className="px-4 py-1.5 bg-slate-900 text-white rounded font-semibold hover:bg-slate-800"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
