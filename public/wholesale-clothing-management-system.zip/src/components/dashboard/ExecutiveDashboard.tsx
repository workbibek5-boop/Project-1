/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useClothingWholesale } from '../../context/ClothingWholesaleContext';
import { formatNpr } from '../../i18n';
import {
  CreditCard,
  Package,
  TrendingUp,
  AlertTriangle,
  Receipt,
  Truck,
  Plus,
  ArrowUpRight,
  Wallet,
  Clock,
  CheckCircle2,
  FileSpreadsheet,
} from 'lucide-react';

interface ExecutiveDashboardProps {
  onNavigate: (tab: string) => void;
}

export const ExecutiveDashboard: React.FC<ExecutiveDashboardProps> = ({ onNavigate }) => {
  const { metrics, sales, expenses, products, settings } = useClothingWholesale();

  // Latest 5 sales
  const recentSales = sales.slice(0, 5);

  // Latest 5 expenses
  const recentExpenses = expenses.slice(0, 5);

  // Urgent low-stock variants
  const urgentLowStockItems: Array<{
    productName: string;
    sku: string;
    size: string;
    color: string;
    stock: number;
    alert: number;
  }> = [];

  const threshold = settings.defaultLowStockThreshold || 15;
  for (const p of products) {
    if (!p.isActive) continue;
    for (const v of p.variants) {
      const alertLimit = v.lowStockAlert !== undefined ? v.lowStockAlert : threshold;
      if (v.stock <= alertLimit) {
        urgentLowStockItems.push({
          productName: p.name,
          sku: v.sku,
          size: v.size,
          color: v.color,
          stock: v.stock,
          alert: alertLimit,
        });
      }
    }
  }

  return (
    <div className="space-y-6">
      {/* Executive Welcome & Date Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
            <span>Executive Overview</span>
            <span aria-hidden="true">·</span>
            <span>Single-Operator Cash Terminal</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 mt-1">
            {settings.businessName}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            {settings.tradingName} · Local IndexedDB Storage · {new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'short', year: 'numeric' })}
          </p>
        </div>

        {/* Quick Launch Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => onNavigate('pos')}
            className="py-2 px-3.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 shadow-2xs"
          >
            <CreditCard className="w-4 h-4 text-amber-400" />
            <span>Open POS Counter</span>
          </button>

          <button
            onClick={() => onNavigate('expenses')}
            className="py-2 px-3 bg-white border border-slate-200 hover:bg-slate-50 text-slate-800 text-xs font-semibold rounded-xl transition-colors flex items-center gap-1.5 shadow-2xs"
          >
            <Wallet className="w-3.5 h-3.5 text-slate-500" />
            <span>Log Expense</span>
          </button>
        </div>
      </div>

      {/* 4 Core Financial KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Today's Sales */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Today's Cash Sales</span>
            <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700">
              <TrendingUp className="w-4 h-4" />
            </span>
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900 mt-2 font-mono">
            {formatNpr(metrics.todaySalesTotal)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
            <span>{metrics.todaySalesCount} cash invoice(s) today</span>
            <button
              onClick={() => onNavigate('sales')}
              className="text-emerald-700 hover:underline font-bold inline-flex items-center gap-0.5"
            >
              Ledger <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Warehouse Inventory Valuation */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Total Stock Pieces</span>
            <span className="p-1.5 rounded-lg bg-slate-100 text-slate-700">
              <Package className="w-4 h-4" />
            </span>
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900 mt-2 font-mono">
            {metrics.totalInventoryPieces.toLocaleString()} <span className="text-xs font-normal text-slate-500">pcs</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
            <span>Cost: <strong>{formatNpr(metrics.totalInventoryCostValuation)}</strong></span>
            <button
              onClick={() => onNavigate('inventory')}
              className="text-slate-900 hover:underline font-bold inline-flex items-center gap-0.5"
            >
              Matrix <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Today's Net Cash Profit */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Today's Net Profit</span>
            <span className="p-1.5 rounded-lg bg-amber-50 text-amber-700">
              <Receipt className="w-4 h-4" />
            </span>
          </div>
          <div className={`text-xl sm:text-2xl font-black mt-2 font-mono ${metrics.todayNetProfit >= 0 ? 'text-slate-900' : 'text-rose-600'}`}>
            {formatNpr(metrics.todayNetProfit)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
            <span>After {formatNpr(metrics.todayExpensesTotal)} expenses</span>
            <button
              onClick={() => onNavigate('reports')}
              className="text-amber-700 hover:underline font-bold inline-flex items-center gap-0.5"
            >
              P&L <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Low Stock Alerts */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Low Stock Re-order</span>
            <span className={`p-1.5 rounded-lg ${metrics.lowStockCount > 0 ? 'bg-rose-50 text-rose-700' : 'bg-slate-100 text-slate-400'}`}>
              <AlertTriangle className="w-4 h-4" />
            </span>
          </div>
          <div className={`text-xl sm:text-2xl font-black mt-2 font-mono ${metrics.lowStockCount > 0 ? 'text-rose-700' : 'text-slate-900'}`}>
            {metrics.lowStockCount} <span className="text-xs font-normal text-slate-500">variants</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
            <span>Threshold: ≤ {threshold} pcs</span>
            <button
              onClick={() => onNavigate('inventory')}
              className="text-rose-700 hover:underline font-bold inline-flex items-center gap-0.5"
            >
              Restock <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Grid: Recent Sales & Low-Stock Watchlist */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Completed Cash Sales (2 cols) */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Receipt className="w-4 h-4 text-slate-700" />
              <h2 className="text-sm font-bold text-slate-900">Recent Cash Sales</h2>
            </div>
            <button
              onClick={() => onNavigate('sales')}
              className="text-xs text-slate-600 hover:text-slate-900 font-semibold"
            >
              View Full History →
            </button>
          </div>

          {recentSales.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">
              No sales recorded yet. Open the POS Cash Billing counter to create your first sale.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-500 text-[11px]">
                    <th className="pb-2 font-semibold">Invoice #</th>
                    <th className="pb-2 font-semibold">Customer</th>
                    <th className="pb-2 font-semibold text-right">Items</th>
                    <th className="pb-2 font-semibold text-right">Grand Total</th>
                    <th className="pb-2 font-semibold text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {recentSales.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-2.5 font-mono font-bold text-slate-900">{s.invoiceNumber}</td>
                      <td className="py-2.5 text-slate-700 truncate max-w-[140px]">
                        {s.customerName || 'Walk-in Cash Buyer'}
                      </td>
                      <td className="py-2.5 text-right font-mono text-slate-600">
                        {s.items.reduce((sum, it) => sum + it.quantity, 0)} pcs
                      </td>
                      <td className="py-2.5 text-right font-mono font-bold text-slate-900">
                        {formatNpr(s.grandTotal)}
                      </td>
                      <td className="py-2.5 text-center">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            s.status === 'completed'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {s.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Low-Stock Warning Watchlist (1 col) */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              <h2 className="text-sm font-bold text-slate-900">Restock Priority</h2>
            </div>
            <button
              onClick={() => onNavigate('inventory')}
              className="text-xs text-rose-700 hover:text-rose-900 font-semibold"
            >
              All Alerts →
            </button>
          </div>

          {urgentLowStockItems.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500 flex flex-col items-center gap-2">
              <CheckCircle2 className="w-6 h-6 text-emerald-600" />
              <span>All garment variants are well stocked above alert thresholds.</span>
            </div>
          ) : (
            <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
              {urgentLowStockItems.slice(0, 6).map((item, idx) => (
                <div key={idx} className="py-2.5 flex items-center justify-between text-xs">
                  <div className="truncate pr-2">
                    <div className="font-semibold text-slate-900 truncate">{item.productName}</div>
                    <div className="text-[11px] text-slate-500 font-mono">
                      {item.size} · {item.color} · SKU: {item.sku}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="font-mono font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded">
                      {item.stock} left
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Recent Cash Expenses & Operations Shortcuts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Expenses */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Wallet className="w-4 h-4 text-slate-700" />
              <h2 className="text-sm font-bold text-slate-900">Recent Shop Expenses</h2>
            </div>
            <button
              onClick={() => onNavigate('expenses')}
              className="text-xs text-slate-600 hover:text-slate-900 font-semibold"
            >
              Manage Expenses →
            </button>
          </div>

          {recentExpenses.length === 0 ? (
            <div className="py-6 text-center text-xs text-slate-500">
              No shop expenses recorded yet. Log daily tea, freight, rent, or packaging to track true net profit.
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {recentExpenses.map((e) => (
                <div key={e.id} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-semibold text-slate-900">{e.description}</div>
                    <div className="text-[11px] text-slate-500">
                      {e.category} · {e.date} {e.voucherNumber ? `· Voucher: ${e.voucherNumber}` : ''}
                    </div>
                  </div>
                  <div className="font-mono font-bold text-slate-900">
                    {formatNpr(e.amount)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Quick Management Shortcuts */}
        <div className="bg-slate-900 text-white rounded-xl p-5 shadow-2xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider">
              <span>Quick Workflows</span>
            </div>
            <h3 className="text-base font-bold text-white mt-1">Single-Operator Navigation</h3>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Fast navigation directly to critical wholesale operations without searching menus.
            </p>
          </div>

          <div className="space-y-2 pt-2">
            <button
              onClick={() => onNavigate('purchases')}
              className="w-full py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-between"
            >
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-amber-400" />
                <span>Receive Mill Shipment</span>
              </div>
              <span className="text-[11px] text-slate-400 font-mono">Stock In</span>
            </button>

            <button
              onClick={() => onNavigate('products')}
              className="w-full py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-between"
            >
              <div className="flex items-center gap-2">
                <Package className="w-4 h-4 text-sky-400" />
                <span>Add / Edit Clothing SKU</span>
              </div>
              <span className="text-[11px] text-slate-400 font-mono">Catalog</span>
            </button>

            <button
              onClick={() => onNavigate('customers')}
              className="w-full py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-between"
            >
              <div className="flex items-center gap-2">
                <Receipt className="w-4 h-4 text-emerald-400" />
                <span>Wholesale Retailer Accounts</span>
              </div>
              <span className="text-[11px] text-slate-400 font-mono">Buyers</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
