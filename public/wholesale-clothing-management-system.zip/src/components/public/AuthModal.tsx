/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useWholesale } from '../../context/WholesaleContext';
import { X, Lock, Building, CheckCircle2, AlertCircle } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { customers, registerCustomer, currentCustomer, setCurrentCustomer } = useWholesale();
  const [mode, setMode] = useState<'login' | 'register'>('login');

  const [loginEmail, setLoginEmail] = useState(currentCustomer?.email || 'workbibek5@gmail.com');
  const [loginError, setLoginError] = useState<string | null>(null);

  // Registration Form
  const [regData, setRegData] = useState({
    name: '',
    email: '',
    phone: '',
    businessName: '',
    businessAddress: '',
    panVatNumber: '',
    licenseNumber: '',
  });
  const [regSuccess, setRegSuccess] = useState(false);

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    const found = customers.find((c) => c.email.toLowerCase() === loginEmail.toLowerCase());
    if (found) {
      setCurrentCustomer(found);
      onClose();
    } else {
      setLoginError('No customer account found with this email. Please check spelling or register.');
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    const res = registerCustomer(regData);
    if (res.success) {
      setRegSuccess(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden">
        {/* Header Tabs */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setMode('login');
                setRegSuccess(false);
              }}
              className={`text-sm font-bold pb-1 border-b-2 transition-colors ${
                mode === 'login' ? 'border-slate-900 text-slate-900' : 'border-transparent text-slate-400'
              }`}
            >
              Customer Login
            </button>
            <span className="text-slate-300">·</span>
            <button
              onClick={() => {
                setMode('register');
                setRegSuccess(false);
              }}
              className={`text-sm font-bold pb-1 border-b-2 transition-colors ${
                mode === 'register' ? 'border-slate-900 text-slate-900' : 'border-transparent text-slate-400'
              }`}
            >
              Register Wholesale Account
            </button>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {mode === 'login' ? (
            <div className="space-y-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">Sign In to Your Wholesale Account</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Access authorized wholesale prices, order history, and category limits.
                </p>
              </div>

              {loginError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{loginError}</span>
                </div>
              )}

              <form onSubmit={handleLogin} className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Registered Business Email *
                  </label>
                  <input
                    type="email"
                    required
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="e.g. store@example.com"
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Password</label>
                  <input
                    type="password"
                    placeholder="••••••••••••"
                    defaultValue="wholesale2026"
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors shadow-sm mt-2"
                >
                  Log In to Customer Portal
                </button>
              </form>

              {/* Quick Persona Logins for instant review */}
              <div className="pt-4 border-t border-slate-100">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-2">
                  Select Existing Verified Retail Account:
                </span>
                <div className="space-y-1.5 max-h-36 overflow-y-auto">
                  {customers.map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => {
                        setLoginEmail(c.email);
                        setCurrentCustomer(c);
                        onClose();
                      }}
                      className="w-full text-left p-2 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200/60 flex items-center justify-between text-xs"
                    >
                      <div>
                        <div className="font-semibold text-slate-900">{c.businessName}</div>
                        <div className="text-[10px] text-slate-500">{c.email}</div>
                      </div>
                      <span className="font-mono text-[10px] font-bold bg-white px-1.5 py-0.5 rounded border border-slate-200">
                        Tier {c.category} ({c.status})
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : regSuccess ? (
            <div className="text-center py-6 space-y-3">
              <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
              <h3 className="text-lg font-bold text-slate-900">Application Submitted!</h3>
              <p className="text-xs text-slate-600 leading-relaxed max-w-sm mx-auto">
                Your business profile has been registered in the system under <strong>Category F</strong> (Initial limit: NPR 35,000) with status <strong>Pending Review</strong>.
              </p>
              <p className="text-[11px] text-slate-500">
                Authorized staff will verify your PAN/VAT details. You can immediately browse catalogue items.
              </p>
              <button
                onClick={onClose}
                className="mt-4 px-6 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800"
              >
                Continue to Store
              </button>
            </div>
          ) : (
            <form onSubmit={handleRegister} className="space-y-3">
              <div>
                <h3 className="text-base font-bold text-slate-900">New Wholesale Buyer Registration</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Register your clothing showroom or boutique for wholesale pricing.
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Business Name *</label>
                <input
                  type="text"
                  required
                  value={regData.businessName}
                  onChange={(e) => setRegData({ ...regData, businessName: e.target.value })}
                  placeholder="e.g. Pokhara Readymade Garment Store"
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Proprietor Name *</label>
                  <input
                    type="text"
                    required
                    value={regData.name}
                    onChange={(e) => setRegData({ ...regData, name: e.target.value })}
                    placeholder="Full Name"
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Phone Number *</label>
                  <input
                    type="tel"
                    required
                    value={regData.phone}
                    onChange={(e) => setRegData({ ...regData, phone: e.target.value })}
                    placeholder="+977-98XXXXXXXX"
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Business Email *</label>
                  <input
                    type="email"
                    required
                    value={regData.email}
                    onChange={(e) => setRegData({ ...regData, email: e.target.value })}
                    placeholder="store@example.com"
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">PAN or VAT No.</label>
                  <input
                    type="text"
                    value={regData.panVatNumber}
                    onChange={(e) => setRegData({ ...regData, panVatNumber: e.target.value })}
                    placeholder="9-digit PAN"
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Store Physical Address *</label>
                <input
                  type="text"
                  required
                  value={regData.businessAddress}
                  onChange={(e) => setRegData({ ...regData, businessAddress: e.target.value })}
                  placeholder="e.g. Mahendrapool, Pokhara, Ward 4"
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Municipal Trade License No.</label>
                <input
                  type="text"
                  value={regData.licenseNumber}
                  onChange={(e) => setRegData({ ...regData, licenseNumber: e.target.value })}
                  placeholder="e.g. REG-2080-XXXX"
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
              </div>

              <div className="bg-slate-50 p-3 rounded-lg text-[11px] text-slate-500 leading-normal">
                Notice: Self-registration allocates initial <strong>Tier F</strong> status (Max limit: NPR 35,000). To qualify for Tier B (NPR 75,000) or Tier C (NPR 200,000), submit your VAT certificate for review.
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors shadow-sm"
              >
                Submit Wholesale Application
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
