/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useClothingWholesale } from '../../context/ClothingWholesaleContext';
import {
  TrendingUp,
  DollarSign,
  Package,
  AlertTriangle,
  Calendar,
  Layers,
  ArrowUpRight,
  TrendingDown,
  ShieldCheck,
  FileSpreadsheet,
} from 'lucide-react';

export const OfflineReportsDashboard: React.FC = () => {
  const {
    products,
    sales,
    purchases,
    expenses,
    stockMovements,
    settings,
    exportSalesCsv,
    exportInventoryCsv,
  } = useClothingWholesale();

  const [dateRangeFilter, setDateRangeFilter] = useState<'today' | '7days' | 'month' | 'all'>('today');

  const todayStr = new Date().toISOString().slice(0, 10);
  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
  const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString();

  // Filter sales based on selected date range
  const filteredSales = sales.filter((s) => {
    if (s.status !== 'completed') return false;
    if (dateRangeFilter === 'today') return s.timestamp.startsWith(todayStr);
    if (dateRangeFilter === '7days') return s.timestamp >= sevenDaysAgo;
    if (dateRangeFilter === 'month') return s.timestamp >= monthStart;
    return true;
  });

  // Filter expenses based on selected date range
  const filteredExpenses = expenses.filter((e) => {
    if (dateRangeFilter === 'today') return e.date === todayStr;
    if (dateRangeFilter === '7days') return e.date >= sevenDaysAgo.slice(0, 10);
    if (dateRangeFilter === 'month') return e.date >= monthStart.slice(0, 10);
    return true;
  });

  // Financial aggregates
  const totalCashSalesNpr = filteredSales.reduce((sum, s) => sum + s.grandTotal, 0);
  const totalExpensesNpr = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);

  // Total cost of goods sold (COGS) for gross profit estimation
  let totalCogsNpr = 0;
  filteredSales.forEach((s) => {
    s.items.forEach((item) => {
      totalCogsNpr += (item.purchaseCostAtSale || 0) * item.quantity;
    });
  });

  const estimatedGrossProfitNpr = totalCashSalesNpr - totalCogsNpr;
  const grossProfitMarginPercent = totalCashSalesNpr > 0
    ? Math.round((estimatedGrossProfitNpr / totalCashSalesNpr) * 100)
    : 0;

  const estimatedNetProfitNpr = estimatedGrossProfitNpr - totalExpensesNpr;

  // Inventory Totals
  const totalVariantsCount = products.reduce((sum, p) => sum + p.variants.length, 0);
  const totalStockPieces = products.reduce((sum, p) => sum + p.totalStock, 0);

  // Stock valuation
  const inventoryValuationCost = products.reduce(
    (sum, p) => sum + p.totalStock * p.purchaseCost,
    0
  );
  const inventoryValuationSelling = products.reduce(
    (sum, p) => sum + p.totalStock * p.sellingPrice,
    0
  );

  // Low stock variants list
  const lowStockVariants: Array<{
    productName: string;
    sku: string;
    size: string;
    color: string;
    stock: number;
    threshold: number;
  }> = [];

  products.forEach((p) => {
    p.variants.forEach((v) => {
      const threshold = v.lowStockAlert ?? settings.defaultLowStockThreshold;
      if (v.stock <= threshold) {
        lowStockVariants.push({
          productName: p.name,
          sku: v.sku,
          size: v.size,
          color: v.color,
          stock: v.stock,
          threshold,
        });
      }
    });
  });

  // Purchases total
  const totalPurchasesNpr = purchases.reduce((sum, p) => sum + p.totalCost, 0);

  // Damaged stock count
  const damagedMovements = stockMovements.filter((m) => m.type === 'damaged');
  const damagedPiecesCount = Math.abs(
    damagedMovements.reduce((sum, m) => sum + m.quantityDelta, 0)
  );

  // Reversals / Refunds
  const refundedSales = sales.filter((s) => s.status === 'refunded');

  return (
    <div className="space-y-6">
      {/* Header and Date Filter */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
            <span>Offline Local Business Intelligence</span>
            <span aria-hidden="true">·</span>
            <span>Zero-Cloud Analytics</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 mt-1">
            Cash Sales, Profit & Inventory Reports
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Real calculations computed in real time from IndexedDB records on this device.
          </p>
        </div>

        {/* Date Filter Bar */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
          {[
            { id: 'today', label: "Today's Sales" },
            { id: '7days', label: 'Last 7 Days' },
            { id: 'month', label: 'This Month' },
            { id: 'all', label: 'All Time' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setDateRangeFilter(tab.id as any)}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                dateRangeFilter === tab.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* KPI Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Cash Sales Total */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
          <span className="text-xs font-medium text-slate-500 block">
            Cash Sales Revenue ({dateRangeFilter})
          </span>
          <span className="text-2xl font-bold font-mono text-slate-900 mt-2 block tabular-nums">
            {settings.currency} {totalCashSalesNpr.toLocaleString('en-IN')}
          </span>
          <span className="text-[11px] text-emerald-700 font-medium mt-1 block">
            {filteredSales.length} completed cash invoice(s)
          </span>
        </div>

        {/* Estimated Gross Profit */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
          <div className="flex justify-between items-start">
            <span className="text-xs font-medium text-slate-500 block">
              Estimated Gross Profit
            </span>
            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 font-mono">
              ~{grossProfitMarginPercent}%
            </span>
          </div>
          <span className="text-2xl font-bold font-mono text-emerald-700 mt-2 block tabular-nums">
            {settings.currency} {estimatedGrossProfitNpr.toLocaleString('en-IN')}
          </span>
          <span className="text-[10px] text-slate-400 mt-1 block">
            Sales revenue minus purchase cost of goods sold
          </span>
        </div>

        {/* Shop Operating Expenses */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
          <span className="text-xs font-medium text-slate-500 block">Operating Shop Expenses</span>
          <span className="text-2xl font-bold font-mono text-rose-700 mt-2 block tabular-nums">
            {settings.currency} {totalExpensesNpr.toLocaleString('en-IN')}
          </span>
          <span className="text-[11px] text-slate-500 mt-1 block">
            {filteredExpenses.length} expense voucher(s) logged
          </span>
        </div>

        {/* True Net Cash Profit */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
          <span className="text-xs font-medium text-slate-500 block">Net Cash Profit</span>
          <span className={`text-2xl font-bold font-mono mt-2 block tabular-nums ${
            estimatedNetProfitNpr >= 0 ? 'text-slate-900' : 'text-rose-600'
          }`}>
            {settings.currency} {estimatedNetProfitNpr.toLocaleString('en-IN')}
          </span>
          <span className="text-[11px] text-slate-500 mt-1 block">
            After deducting COGS & operating expenses
          </span>
        </div>
      </div>

      {/* Stock Valuation & Damaged Stock Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Inventory Valuation Card */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
          <h3 className="text-sm font-bold text-slate-900">Total Warehouse Stock Valuation</h3>
          <p className="text-xs text-slate-500">
            Valuation calculated from local size and colour variant counts.
          </p>

          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-600">Valuation at Purchase Cost:</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">
                {settings.currency} {inventoryValuationCost.toLocaleString('en-IN')}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Expected Wholesale Value:</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">
                {settings.currency} {inventoryValuationSelling.toLocaleString('en-IN')}
              </span>
            </div>
            <div className="pt-2 border-t border-slate-200 flex justify-between font-bold text-emerald-800">
              <span>Potential Gross Margin:</span>
              <span className="font-mono tabular-nums">
                {settings.currency} {(inventoryValuationSelling - inventoryValuationCost).toLocaleString('en-IN')}
              </span>
            </div>
          </div>
        </div>

        {/* Damaged Goods & Refunded Sales Card */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
          <h3 className="text-sm font-bold text-slate-900">Damaged Stock & Sale Reversals</h3>
          <p className="text-xs text-slate-500">
            Audit history of damaged garments and refunded customer invoices.
          </p>

          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-600">Damaged / Written-off Goods:</span>
              <span className="font-mono font-bold text-rose-700 tabular-nums">
                {damagedPiecesCount} pcs
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Cancelled / Refunded Sales:</span>
              <span className="font-mono font-bold text-rose-700 tabular-nums">
                {refundedSales.length} invoice(s)
              </span>
            </div>
            <div className="pt-2 border-t border-slate-200 flex justify-between text-[11px] text-slate-500">
              <span>Integrity:</span>
              <span className="text-slate-700 font-medium">All refunds restored to variant inventory</span>
            </div>
          </div>
        </div>
      </div>

      {/* Low Stock Alert Table */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600" />
            <h3 className="text-sm font-bold text-slate-900">
              Low Stock Warnings ({lowStockVariants.length} Variants)
            </h3>
          </div>
          <span className="text-xs text-slate-500">Threshold: &le; {settings.defaultLowStockThreshold} pcs</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase">
                <th className="py-2.5 px-3">Garment Line</th>
                <th className="py-2.5 px-3">Variant SKU</th>
                <th className="py-2.5 px-3">Size</th>
                <th className="py-2.5 px-3">Colour</th>
                <th className="py-2.5 px-3 text-right">Available Stock</th>
                <th className="py-2.5 px-3 text-right">Warning Level</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {lowStockVariants.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-6 text-center text-slate-400 font-sans">
                    All garment variants have sufficient stock levels.
                  </td>
                </tr>
              ) : (
                lowStockVariants.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/70">
                    <td className="py-2.5 px-3 font-sans font-bold text-slate-900">{item.productName}</td>
                    <td className="py-2.5 px-3 text-slate-600">{item.sku}</td>
                    <td className="py-2.5 px-3 font-bold text-slate-800">{item.size}</td>
                    <td className="py-2.5 px-3 text-slate-800">{item.color}</td>
                    <td className="py-2.5 px-3 text-right font-bold text-rose-600">{item.stock} pcs</td>
                    <td className="py-2.5 px-3 text-right text-slate-400">&le; {item.threshold} pcs</td>
                    <td className="py-2.5 px-3 font-sans">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        item.stock === 0 ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {item.stock === 0 ? 'Out of Stock' : 'Low Stock'}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
