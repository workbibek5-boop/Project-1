/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { useClothingWholesale } from '../../context/ClothingWholesaleContext';
import { WholesaleCustomer } from '../../db/indexedDb';
import { formatNpr } from '../../i18n';
import { useDebounce } from '../../hooks/useDebounce';
import { Pagination } from '../common/Pagination';
import {
  Users,
  Plus,
  Search,
  Phone,
  MapPin,
  FileText,
  CreditCard,
  Edit2,
  Trash2,
  X,
  AlertCircle,
  Building,
} from 'lucide-react';

interface CustomerManagerProps {
  onStartSaleForCustomer?: (customerName: string, customerPhone?: string) => void;
}

export const CustomerManager: React.FC<CustomerManagerProps> = ({ onStartSaleForCustomer }) => {
  const { customers, sales, saveCustomer, deleteCustomer } = useClothingWholesale();

  const [searchQuery, setSearchQuery] = useState('');
  const debouncedSearch = useDebounce(searchQuery, 200);

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(15);

  // Add/Edit modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<WholesaleCustomer | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    businessName: '',
    phone: '',
    email: '',
    panVat: '',
    city: '',
    address: '',
    notes: '',
  });
  const [formError, setFormError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Compute purchase metrics per customer (from completed cash sales)
  const customerSalesStats = useMemo(() => {
    const stats: Record<string, { totalOrders: number; totalSpent: number; lastDate: string }> = {};

    for (const s of sales) {
      if (s.status !== 'completed' || !s.customerName) continue;
      const key = s.customerName.trim().toLowerCase();
      if (!stats[key]) {
        stats[key] = { totalOrders: 0, totalSpent: 0, lastDate: s.timestamp };
      }
      stats[key].totalOrders += 1;
      stats[key].totalSpent += s.grandTotal;
      if (s.timestamp > stats[key].lastDate) {
        stats[key].lastDate = s.timestamp;
      }
    }

    return stats;
  }, [sales]);

  // Filtered customers
  const filteredCustomers = useMemo(() => {
    if (!debouncedSearch.trim()) return customers;
    const q = debouncedSearch.toLowerCase();
    return customers.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        (c.businessName && c.businessName.toLowerCase().includes(q)) ||
        c.phone.includes(q) ||
        c.city.toLowerCase().includes(q) ||
        (c.panVat && c.panVat.includes(q))
    );
  }, [customers, debouncedSearch]);

  const paginatedCustomers = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredCustomers.slice(start, start + itemsPerPage);
  }, [filteredCustomers, currentPage, itemsPerPage]);

  const handleOpenAdd = () => {
    setEditingCustomer(null);
    setFormData({
      name: '',
      businessName: '',
      phone: '',
      email: '',
      panVat: '',
      city: 'Kathmandu',
      address: '',
      notes: '',
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (c: WholesaleCustomer) => {
    setEditingCustomer(c);
    setFormData({
      name: c.name,
      businessName: c.businessName || '',
      phone: c.phone,
      email: c.email || '',
      panVat: c.panVat || '',
      city: c.city,
      address: c.address,
      notes: c.notes || '',
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      setFormError('Customer contact name is required.');
      return;
    }
    if (!formData.phone.trim()) {
      setFormError('Customer phone number is required.');
      return;
    }

    setIsSubmitting(true);
    setFormError(null);

    const customerToSave: WholesaleCustomer = {
      id: editingCustomer ? editingCustomer.id : `cust-${Date.now()}`,
      name: formData.name.trim(),
      businessName: formData.businessName.trim() || undefined,
      phone: formData.phone.trim(),
      email: formData.email.trim() || undefined,
      panVat: formData.panVat.trim() || undefined,
      city: formData.city.trim() || 'Kathmandu',
      address: formData.address.trim(),
      notes: formData.notes.trim() || undefined,
      createdAt: editingCustomer ? editingCustomer.createdAt : new Date().toISOString(),
    };

    const res = await saveCustomer(customerToSave);
    setIsSubmitting(false);

    if (res.success) {
      setIsModalOpen(false);
    } else {
      setFormError(res.error || 'Failed to save customer');
    }
  };

  const handleDelete = async (c: WholesaleCustomer) => {
    if (!confirm(`Delete customer profile "${c.name}"? Previous sale invoices will not be affected.`)) {
      return;
    }
    await deleteCustomer(c.id);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
            <span>Wholesale Client Directory</span>
            <span aria-hidden="true">·</span>
            <span>Retailers & Boutique Buyers</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 mt-1">
            Customer Accounts
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Store retail store names, contact numbers, PAN/VAT IDs, and track their cash purchase history.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-colors flex items-center gap-2 shadow-2xs self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4 text-amber-400" />
          <span>Add New Customer</span>
        </button>
      </div>

      {/* Search & Info Bar */}
      <div className="flex items-center justify-between gap-4 bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by client name, shop name, phone, city, PAN..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900 focus:bg-white"
          />
        </div>
        <div className="text-xs text-slate-500 font-mono">
          <strong>{filteredCustomers.length}</strong> wholesale client(s)
        </div>
      </div>

      {/* Customers Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-4">Customer / Shop Name</th>
                <th className="py-3 px-4">Contact Phone</th>
                <th className="py-3 px-4">City & Address</th>
                <th className="py-3 px-4">PAN / VAT</th>
                <th className="py-3 px-4 text-center">Orders</th>
                <th className="py-3 px-4 text-right">Total Volume</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedCustomers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-xs text-slate-500">
                    No customer accounts match your search query.
                  </td>
                </tr>
              ) : (
                paginatedCustomers.map((c) => {
                  const stat = customerSalesStats[c.name.trim().toLowerCase()] || {
                    totalOrders: 0,
                    totalSpent: 0,
                  };
                  return (
                    <tr key={c.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900 text-sm">{c.name}</div>
                        {c.businessName && (
                          <div className="text-[11px] text-slate-500 flex items-center gap-1 font-semibold">
                            <Building className="w-3 h-3 text-slate-400" />
                            <span>{c.businessName}</span>
                          </div>
                        )}
                        {c.notes && (
                          <div className="text-[10px] text-slate-400 italic max-w-xs truncate">
                            {c.notes}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4 font-mono font-semibold text-slate-800">
                        {c.phone}
                      </td>
                      <td className="py-3 px-4 text-slate-600">
                        <div className="font-medium text-slate-800">{c.city}</div>
                        <div className="text-[11px] text-slate-400 truncate max-w-xs">{c.address}</div>
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-600">
                        {c.panVat || '—'}
                      </td>
                      <td className="py-3 px-4 text-center font-mono font-bold text-slate-900">
                        {stat.totalOrders}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                        {stat.totalSpent > 0 ? formatNpr(stat.totalSpent) : '—'}
                      </td>
                      <td className="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
                        {onStartSaleForCustomer && (
                          <button
                            onClick={() => onStartSaleForCustomer(c.name, c.phone)}
                            className="py-1 px-2.5 rounded bg-amber-50 hover:bg-amber-100 text-slate-950 font-bold transition-colors inline-flex items-center gap-1 text-[11px]"
                            title="Open POS with this customer selected"
                          >
                            <CreditCard className="w-3 h-3 text-amber-700" />
                            <span>New Bill</span>
                          </button>
                        )}
                        <button
                          onClick={() => handleOpenEdit(c)}
                          className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded transition-colors inline-block"
                          title="Edit Customer"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDelete(c)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors inline-block"
                          title="Delete Customer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        <Pagination
          currentPage={currentPage}
          totalItems={filteredCustomers.length}
          itemsPerPage={itemsPerPage}
          onPageChange={setCurrentPage}
          onItemsPerPageChange={setItemsPerPage}
        />
      </div>

      {/* Add / Edit Customer Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in duration-150">
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-sm">
                  {editingCustomer ? 'Edit Wholesale Customer' : 'Add Wholesale Customer'}
                </h3>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-3.5 text-xs">
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                  <span>{formError}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Contact Person Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Ramesh Shrestha"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:ring-1 focus:ring-slate-900 focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Shop / Trade Business Name
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Kathmandu Fashion Point"
                    value={formData.businessName}
                    onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:ring-1 focus:ring-slate-900 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Mobile Phone <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    placeholder="e.g. 9841234567"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg text-slate-900 text-xs font-mono focus:ring-1 focus:ring-slate-900 focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    PAN / VAT Number
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 601234567"
                    value={formData.panVat}
                    onChange={(e) => setFormData({ ...formData, panVat: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg text-slate-900 text-xs font-mono focus:ring-1 focus:ring-slate-900 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">City / Region</label>
                  <input
                    type="text"
                    placeholder="e.g. Kathmandu, Pokhara, Narayangarh"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:ring-1 focus:ring-slate-900 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Street Address</label>
                  <input
                    type="text"
                    placeholder="e.g. Asan Bazar, Shop 14"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:ring-1 focus:ring-slate-900 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Preferences & Notes</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Prefers pack assortments, prompt cash payer..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:ring-1 focus:ring-slate-900 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3.5 py-2 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-lg font-semibold transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white rounded-lg font-bold transition-colors shadow-2xs"
                >
                  {isSubmitting ? 'Saving...' : editingCustomer ? 'Update Profile' : 'Save Customer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
