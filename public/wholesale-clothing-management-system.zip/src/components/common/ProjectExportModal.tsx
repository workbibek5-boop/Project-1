/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  X,
  Download,
  FolderArchive,
  FileCode,
  FileText,
  Terminal,
  Check,
  Copy,
  Folder,
  File,
  CheckCircle2,
} from 'lucide-react';

interface ProjectExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PROJECT_FILES = [
  { path: 'index.html', desc: 'Application HTML entry, PWA manifest tags & fonts' },
  { path: 'package.json', desc: 'NPM dependencies, Vite & React 19 configuration' },
  { path: 'tsconfig.json', desc: 'TypeScript compiler options' },
  { path: 'vite.config.ts', desc: 'Vite build tooling & Tailwind v4 plugins' },
  { path: 'README.md', desc: 'Complete architecture guide & quick start docs' },
  { path: '.env.example', desc: 'Environment variables template' },
  { path: '.gitignore', desc: 'Git ignore rules' },
  { path: 'metadata.json', desc: 'Applet metadata definition' },
  { path: 'public/icon.svg', desc: 'PWA vector icon' },
  { path: 'src/main.tsx', desc: 'React root mounting point' },
  { path: 'src/App.tsx', desc: 'Core application navigation & layout' },
  { path: 'src/index.css', desc: 'Tailwind CSS styles and base typography' },
  { path: 'src/types/index.ts', desc: 'Domain models (Products, Variants, Sales, Settings)' },
  { path: 'src/db/indexedDb.ts', desc: 'IndexedDB persistent storage engine & transactions' },
  { path: 'src/context/ClothingWholesaleContext.tsx', desc: 'Offline-first POS & inventory state engine' },
  { path: 'src/context/WholesaleContext.tsx', desc: 'Preserved B2B marketplace context' },
  { path: 'src/hooks/useOnlineStatus.ts', desc: 'Real-time online/offline network detection' },
  { path: 'src/hooks/usePWAInstall.ts', desc: 'PWA installation prompt trigger' },
  { path: 'src/components/pos/CashBillingPos.tsx', desc: 'Fast wholesale cash POS & dual receipt generator' },
  { path: 'src/components/products/ProductCatalogManager.tsx', desc: 'Variant matrix catalog & stock management' },
  { path: 'src/components/purchases/PurchasesAndStockManager.tsx', desc: 'Stock purchases, damage write-offs & returns' },
  { path: 'src/components/reports/OfflineReportsDashboard.tsx', desc: 'Sales, COGS, gross margin & financial reports' },
  { path: 'src/components/backup/BackupRestoreManager.tsx', desc: 'JSON backup/restore & CSV data portability' },
  { path: 'src/components/settings/OwnerSettingsModal.tsx', desc: 'Business details, tax/PAN, invoice prefixes, PIN' },
  { path: 'src/components/tests/OfflineTestSuite.tsx', desc: 'Automated 9-point offline verification suite' },
  { path: 'src/components/common/AppLockScreen.tsx', desc: 'Owner PIN lock screen protection' },
  { path: 'src/components/common/OfflineStatusBanner.tsx', desc: 'Offline banner & install prompt UI' },
  { path: 'src/data/clothingSeed.ts', desc: 'Offline garment catalog initial seed data' },
  { path: 'src/data/initialData.ts', desc: 'Preserved wholesale business initial dataset' },
  { path: 'src/i18n/index.ts', desc: 'English & Nepali translations & NPR currency formatters' },
];

export const ProjectExportModal: React.FC<ProjectExportModalProps> = ({ isOpen, onClose }) => {
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-3xl w-full border border-slate-200 shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 sm:p-6 flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <FolderArchive className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold">Download Complete Project in a File</h2>
                <span className="px-2 py-0.5 text-[10px] font-bold bg-amber-500 text-slate-950 rounded-full">
                  41 Files
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Wholesale Clothing Management System · Full React 19, TypeScript & PWA Source Code
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Quick Download Buttons */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
              1-Click Project Archive Downloads
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* ZIP Archive */}
              <a
                href="/wholesale-clothing-management-system.zip"
                download="wholesale-clothing-management-system.zip"
                className="p-4 rounded-xl border-2 border-amber-500/60 bg-amber-50/60 hover:bg-amber-100/80 transition-all flex items-center justify-between group shadow-2xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center font-bold text-xs shrink-0 group-hover:scale-105 transition-transform">
                    .ZIP
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900 group-hover:text-amber-900">
                      Standard ZIP Archive
                    </div>
                    <div className="text-[11px] text-slate-600">
                      Recommended for Windows, macOS, VS Code
                    </div>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-amber-600 group-hover:bg-amber-500 text-slate-950 rounded-lg text-xs font-bold">
                    <Download className="w-3.5 h-3.5" />
                    <span>176 KB</span>
                  </span>
                </div>
              </a>

              {/* Tarball Archive */}
              <a
                href="/wholesale-clothing-management-system.tar.gz"
                download="wholesale-clothing-management-system.tar.gz"
                className="p-4 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 transition-all flex items-center justify-between group shadow-2xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-slate-800 text-white flex items-center justify-center font-bold text-xs shrink-0">
                    .TGZ
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      Tarball Archive (.tar.gz)
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Linux / Unix / Docker environments
                    </div>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold">
                    <Download className="w-3.5 h-3.5" />
                    <span>156 KB</span>
                  </span>
                </div>
              </a>

              {/* Single JSON Bundle */}
              <a
                href="/project-bundle.json"
                download="project-bundle.json"
                className="p-4 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 transition-all flex items-center justify-between group shadow-2xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-emerald-700 text-white flex items-center justify-center font-bold text-xs shrink-0">
                    .JSON
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      Single Project JSON File
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Every project file encoded in 1 file
                    </div>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold">
                    <Download className="w-3.5 h-3.5" />
                    <span>685 KB</span>
                  </span>
                </div>
              </a>

              {/* Self-Extracting Bash Script */}
              <a
                href="/setup-project.sh"
                download="setup-project.sh"
                className="p-4 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 transition-all flex items-center justify-between group shadow-2xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-sky-700 text-white flex items-center justify-center font-bold text-xs shrink-0">
                    .SH
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      Self-Extracting Script
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Run `bash setup-project.sh` to extract
                    </div>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold">
                    <Download className="w-3.5 h-3.5" />
                    <span>655 KB</span>
                  </span>
                </div>
              </a>
            </div>
          </div>

          {/* Quick Setup Terminal Commands */}
          <div className="p-4 bg-slate-900 rounded-xl text-slate-100 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
                <Terminal className="w-4 h-4" />
                <span>How to Run Locally After Downloading</span>
              </div>
              <button
                onClick={() =>
                  copyToClipboard(
                    'unzip wholesale-clothing-management-system.zip && npm install && npm run dev',
                    'setup'
                  )
                }
                className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 transition-colors"
              >
                {copiedCmd === 'setup' ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span className="text-emerald-400">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>Copy Commands</span>
                  </>
                )}
              </button>
            </div>
            <pre className="text-xs font-mono bg-slate-950 p-3 rounded-lg overflow-x-auto text-emerald-400 leading-relaxed border border-slate-800">
              # 1. Unzip the project archive{'\n'}
              unzip wholesale-clothing-management-system.zip{'\n\n'}
              # 2. Install dependencies{'\n'}
              npm install{'\n\n'}
              # 3. Start local development server (port 3000){'\n'}
              npm run dev
            </pre>
          </div>

          {/* Included Files Manifest */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Included File Manifest ({PROJECT_FILES.length} core files)
              </h3>
              <span className="text-[11px] text-slate-400">100% Complete & Ready to Run</span>
            </div>
            <div className="border border-slate-200 rounded-xl divide-y divide-slate-100 max-h-56 overflow-y-auto bg-slate-50">
              {PROJECT_FILES.map((f, i) => (
                <div key={i} className="p-2.5 flex items-center justify-between text-xs hover:bg-white transition-colors">
                  <div className="flex items-center gap-2 font-mono text-[11px] text-slate-900 truncate">
                    <FileCode className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{f.path}</span>
                  </div>
                  <div className="text-[11px] text-slate-500 text-right shrink-0 pl-3">
                    {f.desc}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Zero cloud accounts required · IndexedDB offline storage included</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
