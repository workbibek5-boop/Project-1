/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ALL_FASHION_CATEGORIES } from '../data/fashionCategories';

// ============================================================================
// OFFLINE-FIRST INDEXEDDB REPOSITORY FOR CLOTHING WHOLESALE
// ============================================================================

export interface ProductVariant {
  id: string;
  size: string; // e.g., 'XS', 'S', 'M', 'L', 'XL', 'XXL', '32', '34', 'Custom'
  color: string; // e.g., 'Black', 'Navy', 'Olive', 'Maroon'
  design?: string; // Optional pattern or print variation
  sku: string; // e.g., 'SHT-OXF-BLK-M'
  barcode?: string;
  stock: number;
  lowStockAlert?: number;
}

export interface ClothingProduct {
  id: string;
  name: string;
  sku: string;
  barcode?: string;
  department?: string; // 'Formal & Western Wear' | 'Women’s Ethnic Wear' | 'Dresses & Fashion' | 'Men’s Traditional Wear' | 'Textiles & Fabrics'
  category: string;
  brand: string;
  supplier: string;
  manufacturer?: string; // Manufacturer, company, or production-house details
  unit: 'pcs' | 'packs' | 'cartons' | 'metres' | 'rolls';
  packSizePieces?: number; // e.g., 10 or 12 pcs per pack if sold as pack
  purchaseCost: number; // Cost per unit in NPR
  sellingPrice: number; // Wholesale selling price per unit in NPR
  variants: ProductVariant[];
  totalStock: number;
  fabric?: string; // Fabric / material e.g., 'Pure Mulberry Silk', 'Georgette', '100% Cotton'
  designStyleCode?: string; // Design or style code e.g. 'BDL-ZAR-01'
  collectionOccasion?: string; // Collection or occasion e.g. 'Bridal & Trousseau', 'Wedding 2026'
  gstRate?: number; // Configurable GST rate percentage (e.g., 13)
  imageUrl?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface StockMovement {
  id: string;
  productId: string;
  variantId: string;
  productName: string;
  sku: string;
  size: string;
  color: string;
  type:
    | 'purchase'
    | 'cash_sale'
    | 'sale_refund'
    | 'adjustment'
    | 'damaged'
    | 'purchase_return';
  quantityDelta: number; // e.g., -5 for sale, +10 for purchase
  stockBefore: number;
  stockAfter: number;
  referenceId: string; // Invoice number, Purchase ID, or Reason
  reason: string;
  timestamp: string;
}

export interface PurchaseItem {
  productId: string;
  variantId: string;
  productName: string;
  sku: string;
  size: string;
  color: string;
  quantity: number;
  unitCost: number;
  lineTotal: number;
}

export interface PurchaseRecord {
  id: string;
  purchaseNumber: string; // e.g. PUR-2026-0001
  supplierName: string;
  supplierPhone?: string;
  supplierBillNo?: string;
  purchaseDate: string;
  items: PurchaseItem[];
  totalCost: number;
  notes?: string;
  createdAt: string;
}

export interface SaleLineItem {
  productId: string;
  variantId: string;
  productName: string;
  sku: string;
  size: string;
  color: string;
  unit: string;
  unitPrice: number;
  quantity: number;
  discount: number; // flat discount or per item
  lineTotal: number;
  purchaseCostAtSale: number; // to calculate real gross profit offline
}

export interface CashSale {
  id: string;
  invoiceNumber: string; // e.g., INV-2026-0001
  timestamp: string;
  items: SaleLineItem[];
  subtotal: number;
  discountTotal: number;
  taxRatePercent: number;
  taxAmount: number;
  grandTotal: number;
  cashReceived: number;
  changeReturned: number;
  paymentMethod: 'cash';
  customerName?: string;
  customerPhone?: string;
  status: 'completed' | 'cancelled' | 'refunded';
  reversalReason?: string;
  reversedAt?: string;
  notes?: string;
}

export interface AppSettings {
  id: 'main';
  businessName: string;
  tradingName: string;
  panVatNumber: string;
  address: string;
  phone: string;
  email: string;
  currency: string;
  currencySymbol: string;
  invoicePrefix: string;
  invoiceFooterNote: string;
  taxEnabled: boolean;
  defaultVatPercent: number;
  allowNegativeStock: boolean;
  defaultLowStockThreshold: number;
  thermalPrinterWidth: '58mm' | '80mm';
  ownerPinHash?: string; // Optional SHA-256 local app lock
  isAppLocked?: boolean;
  lastBackupDate?: string;
}

export interface WholesaleCustomer {
  id: string;
  name: string;
  businessName?: string;
  phone: string;
  email?: string;
  panVat?: string;
  city: string;
  address: string;
  notes?: string;
  createdAt: string;
}

export interface WholesaleSupplier {
  id: string;
  name: string;
  contactPerson: string;
  phone: string;
  email?: string;
  city: string;
  address: string;
  category: string; // e.g. "Fabric Mill", "Ready-made Garments", "Trims & Zippers"
  notes?: string;
  createdAt: string;
}

export interface WholesaleExpense {
  id: string;
  date: string;
  category: string; // "Shop Rent", "Cargo / Freight", "Packaging Materials", "Staff Tea & Meals", "Electricity & Utilities", "Miscellaneous"
  amount: number;
  description: string;
  voucherNumber?: string;
  paymentMethod: 'cash';
  createdAt: string;
}

export interface WholesaleCategory {
  id: string;
  name: string;
  code: string;
  department?: string; // 'Formal & Western Wear' | 'Women’s Ethnic Wear' | 'Dresses & Fashion' | 'Men’s Traditional Wear' | 'Textiles & Fabrics'
  description?: string;
  createdAt: string;
}

const DB_NAME = 'ClothingWholesaleDB';
const DB_VERSION = 2;

export class ClothingDatabase {
  private db: IDBDatabase | null = null;
  private isConnecting: Promise<IDBDatabase> | null = null;

  async getDb(): Promise<IDBDatabase> {
    if (this.db) return this.db;
    if (this.isConnecting) return this.isConnecting;

    this.isConnecting = new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // 1. Products store
        if (!db.objectStoreNames.contains('products')) {
          const productStore = db.createObjectStore('products', { keyPath: 'id' });
          productStore.createIndex('by_category', 'category', { unique: false });
          productStore.createIndex('by_sku', 'sku', { unique: false });
          productStore.createIndex('by_name', 'name', { unique: false });
        }

        // 2. Purchases store
        if (!db.objectStoreNames.contains('purchases')) {
          const purchaseStore = db.createObjectStore('purchases', { keyPath: 'id' });
          purchaseStore.createIndex('by_number', 'purchaseNumber', { unique: true });
          purchaseStore.createIndex('by_date', 'purchaseDate', { unique: false });
        }

        // 3. Cash Sales store
        if (!db.objectStoreNames.contains('sales')) {
          const salesStore = db.createObjectStore('sales', { keyPath: 'id' });
          salesStore.createIndex('by_invoice', 'invoiceNumber', { unique: true });
          salesStore.createIndex('by_date', 'timestamp', { unique: false });
          salesStore.createIndex('by_status', 'status', { unique: false });
        }

        // 4. Stock Movements store
        if (!db.objectStoreNames.contains('stockMovements')) {
          const movementStore = db.createObjectStore('stockMovements', { keyPath: 'id' });
          movementStore.createIndex('by_product', 'productId', { unique: false });
          movementStore.createIndex('by_timestamp', 'timestamp', { unique: false });
        }

        // 5. Settings store
        if (!db.objectStoreNames.contains('appSettings')) {
          db.createObjectStore('appSettings', { keyPath: 'id' });
        }

        // 6. Customers store (v2)
        if (!db.objectStoreNames.contains('customers')) {
          const customerStore = db.createObjectStore('customers', { keyPath: 'id' });
          customerStore.createIndex('by_name', 'name', { unique: false });
          customerStore.createIndex('by_phone', 'phone', { unique: false });
        }

        // 7. Suppliers store (v2)
        if (!db.objectStoreNames.contains('suppliers')) {
          const supplierStore = db.createObjectStore('suppliers', { keyPath: 'id' });
          supplierStore.createIndex('by_name', 'name', { unique: false });
        }

        // 8. Expenses store (v2)
        if (!db.objectStoreNames.contains('expenses')) {
          const expenseStore = db.createObjectStore('expenses', { keyPath: 'id' });
          expenseStore.createIndex('by_date', 'date', { unique: false });
          expenseStore.createIndex('by_category', 'category', { unique: false });
        }

        // 9. Categories store (v2)
        if (!db.objectStoreNames.contains('categories')) {
          db.createObjectStore('categories', { keyPath: 'id' });
        }
      };

      request.onsuccess = () => {
        this.db = request.result;
        resolve(this.db);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });

    return this.isConnecting;
  }

  // --------------------------------------------------------------------------
  // PRODUCTS & VARIANTS
  // --------------------------------------------------------------------------

  async getAllProducts(): Promise<ClothingProduct[]> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('products', 'readonly');
      const store = tx.objectStore('products');
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }

  async getProduct(id: string): Promise<ClothingProduct | undefined> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('products', 'readonly');
      const store = tx.objectStore('products');
      const request = store.get(id);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async saveProduct(product: ClothingProduct): Promise<void> {
    const db = await this.getDb();
    // Recompute totalStock from variants
    const totalStock = product.variants.reduce((sum, v) => sum + (Number(v.stock) || 0), 0);
    const updated: ClothingProduct = {
      ...product,
      totalStock,
      updatedAt: new Date().toISOString(),
    };

    return new Promise((resolve, reject) => {
      const tx = db.transaction('products', 'readwrite');
      const store = tx.objectStore('products');
      const request = store.put(updated);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async deleteProduct(id: string): Promise<void> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('products', 'readwrite');
      const store = tx.objectStore('products');
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // --------------------------------------------------------------------------
  // ATOMIC CASH SALE & INVENTORY REDUCTION
  // --------------------------------------------------------------------------

  async processCashSale(
    saleData: Omit<CashSale, 'id' | 'timestamp' | 'status'>,
    allowNegativeStock: boolean = false
  ): Promise<{ success: boolean; sale?: CashSale; error?: string }> {
    const db = await this.getDb();
    const timestamp = new Date().toISOString();
    const saleId = `sale-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    return new Promise((resolve) => {
      const tx = db.transaction(['products', 'sales', 'stockMovements'], 'readwrite');
      const productStore = tx.objectStore('products');
      const salesStore = tx.objectStore('sales');
      const movementStore = tx.objectStore('stockMovements');

      const sale: CashSale = {
        ...saleData,
        id: saleId,
        timestamp,
        status: 'completed',
      };

      // Step 1: Pre-fetch and check all products involved
      const productRequests: Promise<{ product: ClothingProduct; item: SaleLineItem }>[] = [];

      for (const item of sale.items) {
        const pReq = new Promise<{ product: ClothingProduct; item: SaleLineItem }>((res, rej) => {
          const req = productStore.get(item.productId);
          req.onsuccess = () => {
            if (!req.result) {
              rej(new Error(`Product "${item.productName}" not found in database.`));
            } else {
              res({ product: req.result, item });
            }
          };
          req.onerror = () => rej(req.error);
        });
        productRequests.push(pReq);
      }

      Promise.all(productRequests)
        .then((resolvedItems) => {
          // Verify stock for all items BEFORE mutating anything
          for (const { product, item } of resolvedItems) {
            const variant = product.variants.find((v) => v.id === item.variantId);
            if (!variant) {
              tx.abort();
              resolve({
                success: false,
                error: `Variant (${item.size} / ${item.color}) for "${product.name}" not found.`,
              });
              return;
            }

            if (!allowNegativeStock && variant.stock < item.quantity) {
              tx.abort();
              resolve({
                success: false,
                error: `Insufficient stock for "${product.name}" (${item.size} / ${item.color}). Requested: ${item.quantity}, Available: ${variant.stock}`,
              });
              return;
            }
          }

          // Step 2: Mutate stock and write movements
          const updatedProductsMap = new Map<string, ClothingProduct>();

          for (const { product, item } of resolvedItems) {
            const currentProd = updatedProductsMap.get(product.id) || product;
            const variantIndex = currentProd.variants.findIndex((v) => v.id === item.variantId);
            const variant = currentProd.variants[variantIndex];

            const stockBefore = variant.stock;
            const stockAfter = stockBefore - item.quantity;

            const updatedVariant: ProductVariant = {
              ...variant,
              stock: stockAfter,
            };

            const updatedVariants = [...currentProd.variants];
            updatedVariants[variantIndex] = updatedVariant;

            const updatedProduct: ClothingProduct = {
              ...currentProd,
              variants: updatedVariants,
              totalStock: updatedVariants.reduce((s, v) => s + v.stock, 0),
              updatedAt: timestamp,
            };

            updatedProductsMap.set(product.id, updatedProduct);

            // Record stock movement
            const movement: StockMovement = {
              id: `mov-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
              productId: product.id,
              variantId: variant.id,
              productName: product.name,
              sku: variant.sku,
              size: variant.size,
              color: variant.color,
              type: 'cash_sale',
              quantityDelta: -item.quantity,
              stockBefore,
              stockAfter,
              referenceId: sale.invoiceNumber,
              reason: `Cash Sale Invoice #${sale.invoiceNumber}`,
              timestamp,
            };
            movementStore.put(movement);
          }

          // Save all updated products
          for (const p of updatedProductsMap.values()) {
            productStore.put(p);
          }

          // Save Sale Record
          salesStore.put(sale);
        })
        .catch((err) => {
          tx.abort();
          resolve({ success: false, error: err.message || 'Database error during sale processing' });
        });

      tx.oncomplete = () => {
        resolve({ success: true, sale });
      };

      tx.onerror = () => {
        resolve({
          success: false,
          error: tx.error?.message || 'Transaction aborted or failed.',
        });
      };
    });
  }

  // --------------------------------------------------------------------------
  // ATOMIC SALE REVERSAL / REFUND (RESTORES STOCK)
  // --------------------------------------------------------------------------

  async reverseSale(
    saleId: string,
    reason: string
  ): Promise<{ success: boolean; error?: string }> {
    const db = await this.getDb();
    const timestamp = new Date().toISOString();

    return new Promise((resolve) => {
      const tx = db.transaction(['products', 'sales', 'stockMovements'], 'readwrite');
      const salesStore = tx.objectStore('sales');
      const productStore = tx.objectStore('products');
      const movementStore = tx.objectStore('stockMovements');

      const saleReq = salesStore.get(saleId);

      saleReq.onsuccess = () => {
        const sale: CashSale = saleReq.result;
        if (!sale) {
          tx.abort();
          resolve({ success: false, error: 'Sale record not found.' });
          return;
        }

        if (sale.status !== 'completed') {
          tx.abort();
          resolve({
            success: false,
            error: `Sale has already been marked as ${sale.status}.`,
          });
          return;
        }

        // Update sale record
        sale.status = 'refunded';
        sale.reversalReason = reason;
        sale.reversedAt = timestamp;
        salesStore.put(sale);

        // Restore stock for all items
        for (const item of sale.items) {
          const prodReq = productStore.get(item.productId);
          prodReq.onsuccess = () => {
            const product: ClothingProduct = prodReq.result;
            if (product) {
              const vIdx = product.variants.findIndex((v) => v.id === item.variantId);
              if (vIdx !== -1) {
                const variant = product.variants[vIdx];
                const stockBefore = variant.stock;
                const stockAfter = stockBefore + item.quantity;

                const updatedVariant = { ...variant, stock: stockAfter };
                const updatedVariants = [...product.variants];
                updatedVariants[vIdx] = updatedVariant;

                const updatedProduct: ClothingProduct = {
                  ...product,
                  variants: updatedVariants,
                  totalStock: updatedVariants.reduce((s, v) => s + v.stock, 0),
                  updatedAt: timestamp,
                };
                productStore.put(updatedProduct);

                // Stock movement log
                const movement: StockMovement = {
                  id: `mov-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
                  productId: product.id,
                  variantId: variant.id,
                  productName: product.name,
                  sku: variant.sku,
                  size: variant.size,
                  color: variant.color,
                  type: 'sale_refund',
                  quantityDelta: +item.quantity,
                  stockBefore,
                  stockAfter,
                  referenceId: sale.invoiceNumber,
                  reason: `Sale Reversal: ${reason}`,
                  timestamp,
                };
                movementStore.put(movement);
              }
            }
          };
        }
      };

      tx.oncomplete = () => resolve({ success: true });
      tx.onerror = () => resolve({ success: false, error: tx.error?.message || 'Reversal failed.' });
    });
  }

  // --------------------------------------------------------------------------
  // ATOMIC STOCK PURCHASE & STOCK ADJUSTMENT
  // --------------------------------------------------------------------------

  async recordPurchase(
    purchase: Omit<PurchaseRecord, 'id' | 'createdAt'>
  ): Promise<{ success: boolean; purchase?: PurchaseRecord; error?: string }> {
    const db = await this.getDb();
    const timestamp = new Date().toISOString();
    const purchaseId = `pur-${Date.now()}`;

    return new Promise((resolve) => {
      const tx = db.transaction(['products', 'purchases', 'stockMovements'], 'readwrite');
      const purchaseStore = tx.objectStore('purchases');
      const productStore = tx.objectStore('products');
      const movementStore = tx.objectStore('stockMovements');

      const fullPurchase: PurchaseRecord = {
        ...purchase,
        id: purchaseId,
        createdAt: timestamp,
      };

      purchaseStore.put(fullPurchase);

      // Increment stock for each item
      for (const item of purchase.items) {
        const prodReq = productStore.get(item.productId);
        prodReq.onsuccess = () => {
          const product: ClothingProduct = prodReq.result;
          if (product) {
            const vIdx = product.variants.findIndex((v) => v.id === item.variantId);
            if (vIdx !== -1) {
              const variant = product.variants[vIdx];
              const stockBefore = variant.stock;
              const stockAfter = stockBefore + item.quantity;

              const updatedVariant = { ...variant, stock: stockAfter };
              const updatedVariants = [...product.variants];
              updatedVariants[vIdx] = updatedVariant;

              const updatedProduct: ClothingProduct = {
                ...product,
                variants: updatedVariants,
                totalStock: updatedVariants.reduce((s, v) => s + v.stock, 0),
                updatedAt: timestamp,
              };
              productStore.put(updatedProduct);

              // Movement log
              const movement: StockMovement = {
                id: `mov-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
                productId: product.id,
                variantId: variant.id,
                productName: product.name,
                sku: variant.sku,
                size: variant.size,
                color: variant.color,
                type: 'purchase',
                quantityDelta: +item.quantity,
                stockBefore,
                stockAfter,
                referenceId: fullPurchase.purchaseNumber,
                reason: `Stock Purchase: ${purchase.supplierName}`,
                timestamp,
              };
              movementStore.put(movement);
            }
          }
        };
      }

      tx.oncomplete = () => resolve({ success: true, purchase: fullPurchase });
      tx.onerror = () => resolve({ success: false, error: tx.error?.message || 'Purchase entry failed.' });
    });
  }

  async recordStockAdjustment(
    productId: string,
    variantId: string,
    delta: number,
    type: 'adjustment' | 'damaged' | 'purchase_return',
    reason: string
  ): Promise<{ success: boolean; error?: string }> {
    const db = await this.getDb();
    const timestamp = new Date().toISOString();

    return new Promise((resolve) => {
      const tx = db.transaction(['products', 'stockMovements'], 'readwrite');
      const productStore = tx.objectStore('products');
      const movementStore = tx.objectStore('stockMovements');

      const prodReq = productStore.get(productId);
      prodReq.onsuccess = () => {
        const product: ClothingProduct = prodReq.result;
        if (!product) {
          tx.abort();
          resolve({ success: false, error: 'Product not found.' });
          return;
        }

        const vIdx = product.variants.findIndex((v) => v.id === variantId);
        if (vIdx === -1) {
          tx.abort();
          resolve({ success: false, error: 'Variant not found.' });
          return;
        }

        const variant = product.variants[vIdx];
        const stockBefore = variant.stock;
        const stockAfter = stockBefore + delta;

        if (stockAfter < 0) {
          tx.abort();
          resolve({ success: false, error: `Stock cannot become negative (${stockAfter}).` });
          return;
        }

        const updatedVariant = { ...variant, stock: stockAfter };
        const updatedVariants = [...product.variants];
        updatedVariants[vIdx] = updatedVariant;

        const updatedProduct: ClothingProduct = {
          ...product,
          variants: updatedVariants,
          totalStock: updatedVariants.reduce((s, v) => s + v.stock, 0),
          updatedAt: timestamp,
        };
        productStore.put(updatedProduct);

        const movement: StockMovement = {
          id: `mov-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          productId: product.id,
          variantId: variant.id,
          productName: product.name,
          sku: variant.sku,
          size: variant.size,
          color: variant.color,
          type,
          quantityDelta: delta,
          stockBefore,
          stockAfter,
          referenceId: 'ADJUSTMENT',
          reason,
          timestamp,
        };
        movementStore.put(movement);
      };

      tx.oncomplete = () => resolve({ success: true });
      tx.onerror = () => resolve({ success: false, error: tx.error?.message || 'Adjustment failed.' });
    });
  }

  // --------------------------------------------------------------------------
  // QUERIES FOR SALES, PURCHASES, MOVEMENTS, SETTINGS
  // --------------------------------------------------------------------------

  async getAllSales(): Promise<CashSale[]> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('sales', 'readonly');
      const store = tx.objectStore('sales');
      const request = store.getAll();
      request.onsuccess = () => {
        // Return latest first
        const sales: CashSale[] = request.result || [];
        sales.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        resolve(sales);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async getAllPurchases(): Promise<PurchaseRecord[]> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('purchases', 'readonly');
      const store = tx.objectStore('purchases');
      const request = store.getAll();
      request.onsuccess = () => {
        const purchases: PurchaseRecord[] = request.result || [];
        purchases.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        resolve(purchases);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async getAllStockMovements(): Promise<StockMovement[]> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('stockMovements', 'readonly');
      const store = tx.objectStore('stockMovements');
      const request = store.getAll();
      request.onsuccess = () => {
        const movements: StockMovement[] = request.result || [];
        movements.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        resolve(movements);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async getSettings(): Promise<AppSettings> {
    const db = await this.getDb();
    return new Promise((resolve) => {
      const tx = db.transaction('appSettings', 'readonly');
      const store = tx.objectStore('appSettings');
      const request = store.get('main');
      request.onsuccess = () => {
        if (request.result) {
          resolve(request.result);
        } else {
          // Default settings
          const defaultSettings: AppSettings = {
            id: 'main',
            businessName: 'My Wholesale Business',
            tradingName: 'Himalayan Garment Wholesale',
            panVatNumber: '601234567',
            address: 'New Road Garment Hub, Kathmandu, Nepal',
            phone: '+977-1-4220000',
            email: 'sales@example.com',
            currency: 'NPR',
            currencySymbol: 'रू',
            invoicePrefix: 'INV-2026-',
            invoiceFooterNote: 'Thank you for your business. Wholesale goods sold in cash terms.',
            taxEnabled: true,
            defaultVatPercent: 13,
            allowNegativeStock: false,
            defaultLowStockThreshold: 15,
            thermalPrinterWidth: '80mm',
          };
          // Persist default
          this.saveSettings(defaultSettings).catch(console.error);
          resolve(defaultSettings);
        }
      };
      request.onerror = () => {
        // Fallback default
        resolve({
          id: 'main',
          businessName: 'My Wholesale Business',
          tradingName: 'Himalayan Garment Wholesale',
          panVatNumber: '601234567',
          address: 'New Road Garment Hub, Kathmandu, Nepal',
          phone: '+977-1-4220000',
          email: 'sales@example.com',
          currency: 'NPR',
          currencySymbol: 'रू',
          invoicePrefix: 'INV-2026-',
          invoiceFooterNote: 'Thank you for your business. Wholesale goods sold in cash terms.',
          taxEnabled: true,
          defaultVatPercent: 13,
          allowNegativeStock: false,
          defaultLowStockThreshold: 15,
          thermalPrinterWidth: '80mm',
        });
      };
    });
  }

  async saveSettings(settings: AppSettings): Promise<void> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('appSettings', 'readwrite');
      const store = tx.objectStore('appSettings');
      const request = store.put(settings);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // --------------------------------------------------------------------------
  // CUSTOMERS (v2)
  // --------------------------------------------------------------------------

  async getAllCustomers(): Promise<WholesaleCustomer[]> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('customers', 'readonly');
      const store = tx.objectStore('customers');
      const request = store.getAll();
      request.onsuccess = () => {
        const list: WholesaleCustomer[] = request.result || [];
        list.sort((a, b) => a.name.localeCompare(b.name));
        resolve(list);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async saveCustomer(customer: WholesaleCustomer): Promise<void> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('customers', 'readwrite');
      const store = tx.objectStore('customers');
      const request = store.put(customer);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async deleteCustomer(id: string): Promise<void> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('customers', 'readwrite');
      const store = tx.objectStore('customers');
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // --------------------------------------------------------------------------
  // SUPPLIERS (v2)
  // --------------------------------------------------------------------------

  async getAllSuppliers(): Promise<WholesaleSupplier[]> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('suppliers', 'readonly');
      const store = tx.objectStore('suppliers');
      const request = store.getAll();
      request.onsuccess = () => {
        const list: WholesaleSupplier[] = request.result || [];
        list.sort((a, b) => a.name.localeCompare(b.name));
        resolve(list);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async saveSupplier(supplier: WholesaleSupplier): Promise<void> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('suppliers', 'readwrite');
      const store = tx.objectStore('suppliers');
      const request = store.put(supplier);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async deleteSupplier(id: string): Promise<void> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('suppliers', 'readwrite');
      const store = tx.objectStore('suppliers');
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // --------------------------------------------------------------------------
  // EXPENSES (v2)
  // --------------------------------------------------------------------------

  async getAllExpenses(): Promise<WholesaleExpense[]> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('expenses', 'readonly');
      const store = tx.objectStore('expenses');
      const request = store.getAll();
      request.onsuccess = () => {
        const list: WholesaleExpense[] = request.result || [];
        list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        resolve(list);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async saveExpense(expense: WholesaleExpense): Promise<void> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('expenses', 'readwrite');
      const store = tx.objectStore('expenses');
      const request = store.put(expense);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async deleteExpense(id: string): Promise<void> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('expenses', 'readwrite');
      const store = tx.objectStore('expenses');
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // --------------------------------------------------------------------------
  // CATEGORIES (v2)
  // --------------------------------------------------------------------------

  async getAllCategories(): Promise<WholesaleCategory[]> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('categories', 'readonly');
      const store = tx.objectStore('categories');
      const request = store.getAll();
      request.onsuccess = () => {
        const list: WholesaleCategory[] = request.result || [];
        list.sort((a, b) => a.name.localeCompare(b.name));
        resolve(list);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async saveCategory(category: WholesaleCategory): Promise<void> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('categories', 'readwrite');
      const store = tx.objectStore('categories');
      const request = store.put(category);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async deleteCategory(id: string): Promise<void> {
    const db = await this.getDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('categories', 'readwrite');
      const store = tx.objectStore('categories');
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // --------------------------------------------------------------------------
  // BACKUP & RESTORE
  // --------------------------------------------------------------------------

  async exportFullBackup(): Promise<{
    version: number;
    exportDate: string;
    products: ClothingProduct[];
    purchases: PurchaseRecord[];
    sales: CashSale[];
    stockMovements: StockMovement[];
    settings: AppSettings;
    customers?: WholesaleCustomer[];
    suppliers?: WholesaleSupplier[];
    expenses?: WholesaleExpense[];
    categories?: WholesaleCategory[];
  }> {
    const [products, purchases, sales, stockMovements, settings, customers, suppliers, expenses, categories] =
      await Promise.all([
        this.getAllProducts(),
        this.getAllPurchases(),
        this.getAllSales(),
        this.getAllStockMovements(),
        this.getSettings(),
        this.getAllCustomers(),
        this.getAllSuppliers(),
        this.getAllExpenses(),
        this.getAllCategories(),
      ]);

    return {
      version: 2,
      exportDate: new Date().toISOString(),
      products,
      purchases,
      sales,
      stockMovements,
      settings,
      customers,
      suppliers,
      expenses,
      categories,
    };
  }

  async restoreFullBackup(backupData: any): Promise<{ success: boolean; error?: string }> {
    // Validate backup format
    if (!backupData || typeof backupData !== 'object') {
      return { success: false, error: 'Invalid backup file format.' };
    }
    if (!Array.isArray(backupData.products) || !Array.isArray(backupData.sales)) {
      return { success: false, error: 'Backup is missing required product or sales collections.' };
    }

    const db = await this.getDb();
    const storeNames = ['products', 'purchases', 'sales', 'stockMovements', 'appSettings'];
    if (db.objectStoreNames.contains('customers')) storeNames.push('customers');
    if (db.objectStoreNames.contains('suppliers')) storeNames.push('suppliers');
    if (db.objectStoreNames.contains('expenses')) storeNames.push('expenses');
    if (db.objectStoreNames.contains('categories')) storeNames.push('categories');

    return new Promise((resolve) => {
      const tx = db.transaction(storeNames, 'readwrite');

      // Clear existing stores
      tx.objectStore('products').clear();
      tx.objectStore('purchases').clear();
      tx.objectStore('sales').clear();
      tx.objectStore('stockMovements').clear();
      tx.objectStore('appSettings').clear();

      if (db.objectStoreNames.contains('customers')) tx.objectStore('customers').clear();
      if (db.objectStoreNames.contains('suppliers')) tx.objectStore('suppliers').clear();
      if (db.objectStoreNames.contains('expenses')) tx.objectStore('expenses').clear();
      if (db.objectStoreNames.contains('categories')) tx.objectStore('categories').clear();

      // Repopulate products
      const prodStore = tx.objectStore('products');
      for (const p of backupData.products) {
        prodStore.put(p);
      }

      // Repopulate purchases
      if (Array.isArray(backupData.purchases)) {
        const purStore = tx.objectStore('purchases');
        for (const pur of backupData.purchases) {
          purStore.put(pur);
        }
      }

      // Repopulate sales
      const salesStore = tx.objectStore('sales');
      for (const s of backupData.sales) {
        salesStore.put(s);
      }

      // Repopulate movements
      if (Array.isArray(backupData.stockMovements)) {
        const movStore = tx.objectStore('stockMovements');
        for (const m of backupData.stockMovements) {
          movStore.put(m);
        }
      }

      // Repopulate settings
      if (backupData.settings) {
        tx.objectStore('appSettings').put({
          ...backupData.settings,
          id: 'main',
          lastBackupDate: new Date().toISOString(),
        });
      }

      // Repopulate v2 stores if present
      if (Array.isArray(backupData.customers) && db.objectStoreNames.contains('customers')) {
        const custStore = tx.objectStore('customers');
        for (const c of backupData.customers) {
          custStore.put(c);
        }
      }

      if (Array.isArray(backupData.suppliers) && db.objectStoreNames.contains('suppliers')) {
        const suppStore = tx.objectStore('suppliers');
        for (const supp of backupData.suppliers) {
          suppStore.put(supp);
        }
      }

      if (Array.isArray(backupData.expenses) && db.objectStoreNames.contains('expenses')) {
        const expStore = tx.objectStore('expenses');
        for (const exp of backupData.expenses) {
          expStore.put(exp);
        }
      }

      if (Array.isArray(backupData.categories) && db.objectStoreNames.contains('categories')) {
        const catStore = tx.objectStore('categories');
        for (const cat of backupData.categories) {
          catStore.put(cat);
        }
      }

      tx.oncomplete = () => resolve({ success: true });
      tx.onerror = () => resolve({ success: false, error: tx.error?.message || 'Restore failed' });
    });
  }

  // --------------------------------------------------------------------------
  // INITIAL SEEDING (FROM LOCAL GARMENT DATA IF DB IS EMPTY)
  // --------------------------------------------------------------------------
  async seedInitialDataIfEmpty(initialProducts: ClothingProduct[]): Promise<void> {
    const existing = await this.getAllProducts();
    if (existing.length === 0 && initialProducts.length > 0) {
      const db = await this.getDb();
      const tx = db.transaction(['products', 'stockMovements'], 'readwrite');
      const prodStore = tx.objectStore('products');
      const movStore = tx.objectStore('stockMovements');

      for (const prod of initialProducts) {
        prodStore.put(prod);
        for (const variant of prod.variants) {
          movStore.put({
            id: `mov-init-${prod.id}-${variant.id}`,
            productId: prod.id,
            variantId: variant.id,
            productName: prod.name,
            sku: variant.sku,
            size: variant.size,
            color: variant.color,
            type: 'purchase',
            quantityDelta: variant.stock,
            stockBefore: 0,
            stockAfter: variant.stock,
            referenceId: 'INITIAL_STOCK',
            reason: 'Opening Inventory Stock',
            timestamp: new Date().toISOString(),
          });
        }
      }
    }
  }

  async seedAdditionalModulesIfEmpty(): Promise<void> {
    const db = await this.getDb();

    // 1. Categories (Ensure all fashion hierarchy categories exist)
    const existingCats = await this.getAllCategories();
    const existingCatNames = new Set(existingCats.map((c) => c.name.toLowerCase()));

    for (let i = 0; i < ALL_FASHION_CATEGORIES.length; i++) {
      const item = ALL_FASHION_CATEGORIES[i];
      if (!existingCatNames.has(item.category.toLowerCase())) {
        await this.saveCategory({
          id: `cat-fash-${i + 1}-${item.code.toLowerCase()}`,
          name: item.category,
          code: item.code,
          department: item.department,
          description: item.description,
          createdAt: new Date().toISOString(),
        });
        existingCatNames.add(item.category.toLowerCase());
      }
    }

    // 2. Customers
    const existingCust = await this.getAllCustomers();
    if (existingCust.length === 0) {
      const defaultCustomers: WholesaleCustomer[] = [
        {
          id: 'cust-1',
          name: 'Rajesh Shrestha',
          businessName: 'Kathmandu Fashion Point',
          phone: '9841234567',
          email: 'rajesh.kfp@gmail.com',
          panVat: '301298451',
          city: 'Kathmandu',
          address: 'Asan Bazar, Ward 27',
          notes: 'Frequent buyer of denim packs and Oxford shirts. Cash prompt.',
          createdAt: new Date().toISOString(),
        },
        {
          id: 'cust-2',
          name: 'Sunita Gurung',
          businessName: 'Pokhara Valley Collection',
          phone: '9856012345',
          email: 'pokhara.collection@gmail.com',
          city: 'Pokhara',
          address: 'Mahendrapool, Pokhara',
          notes: 'Buys winter hoodies and fleece jackets in bulk.',
          createdAt: new Date().toISOString(),
        },
        {
          id: 'cust-3',
          name: 'Bikram Thapa',
          businessName: 'Chitwan Garment Centre',
          phone: '9801234890',
          panVat: '601984210',
          city: 'Narayangarh',
          address: 'Lions Chowk, Narayangarh',
          notes: 'Orders in dozens. Prefers pack assortments.',
          createdAt: new Date().toISOString(),
        },
      ];
      for (const c of defaultCustomers) {
        await this.saveCustomer(c);
      }
    }

    // 3. Suppliers
    const existingSupp = await this.getAllSuppliers();
    if (existingSupp.length === 0) {
      const defaultSuppliers: WholesaleSupplier[] = [
        {
          id: 'supp-1',
          name: 'Himalayan Textile Mills',
          contactPerson: 'Suresh Agrawal',
          phone: '01-4351234',
          email: 'orders@himalayantextiles.com.np',
          city: 'Biratnagar',
          address: 'Mills Area, Biratnagar-13',
          category: 'Fabric & Mill Direct',
          notes: 'Primary supplier for 100% Egyptian Giza & Oxford cotton fabrics.',
          createdAt: new Date().toISOString(),
        },
        {
          id: 'supp-2',
          name: 'Apex Knitwear Apparels',
          contactPerson: 'Deepak Sharma',
          phone: '01-5521980',
          city: 'Lalitpur',
          address: 'Patan Industrial Estate',
          category: 'Ready-made Garments',
          notes: 'Manufactures pre-shrunk combed cotton T-shirts and polos.',
          createdAt: new Date().toISOString(),
        },
        {
          id: 'supp-3',
          name: 'Bagmati Denim Industries',
          contactPerson: 'Prakash Maharjan',
          phone: '01-4478901',
          city: 'Kathmandu',
          address: 'Balaju Industrial District',
          category: 'Denim Manufacturing',
          notes: 'Specialist in stone-wash and enzyme washed denim jeans.',
          createdAt: new Date().toISOString(),
        },
      ];
      for (const s of defaultSuppliers) {
        await this.saveSupplier(s);
      }
    }

    // 4. Sample Expenses
    const existingExp = await this.getAllExpenses();
    if (existingExp.length === 0) {
      const today = new Date().toISOString().slice(0, 10);
      const defaultExpenses: WholesaleExpense[] = [
        {
          id: 'exp-1',
          date: today,
          category: 'Shop Rent',
          amount: 25000,
          description: 'Monthly warehouse and counter shop rent',
          voucherNumber: 'VCH-001',
          paymentMethod: 'cash',
          createdAt: new Date().toISOString(),
        },
        {
          id: 'exp-2',
          date: today,
          category: 'Cargo / Freight',
          amount: 3800,
          description: 'Biratnagar mill consignment freight & unloading labour',
          voucherNumber: 'VCH-002',
          paymentMethod: 'cash',
          createdAt: new Date().toISOString(),
        },
        {
          id: 'exp-3',
          date: today,
          category: 'Staff Tea & Meals',
          amount: 650,
          description: 'Daily counter tea and lunch for helper',
          voucherNumber: 'VCH-003',
          paymentMethod: 'cash',
          createdAt: new Date().toISOString(),
        },
      ];
      for (const e of defaultExpenses) {
        await this.saveExpense(e);
      }
    }
  }
}

export const clothingDb = new ClothingDatabase();

