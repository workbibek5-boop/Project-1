/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { WholesaleProvider } from './context/WholesaleContext';
import { ClothingWholesaleProvider, useClothingWholesale } from './context/ClothingWholesaleContext';

// Offline Clothing Wholesale Core Components
import { OfflineStatusBanner } from './components/common/OfflineStatusBanner';
import { AppLockScreen } from './components/common/AppLockScreen';
import { ProjectExportModal } from './components/common/ProjectExportModal';
import { AppSidebar } from './components/layout/AppSidebar';
import { ExecutiveDashboard } from './components/dashboard/ExecutiveDashboard';
import { FashionCollectionShowcase } from './components/fashion/FashionCollectionShowcase';
import { CashBillingPos } from './components/pos/CashBillingPos';
import { SalesHistoryManager } from './components/sales/SalesHistoryManager';
import { ProductCatalogManager } from './components/products/ProductCatalogManager';
import { CategoryManager } from './components/categories/CategoryManager';
import { InventoryStockMatrix } from './components/inventory/InventoryStockMatrix';
import { PurchasesAndStockManager } from './components/purchases/PurchasesAndStockManager';
import { CustomerManager } from './components/customers/CustomerManager';
import { SupplierManager } from './components/suppliers/SupplierManager';
import { ExpenseManager } from './components/expenses/ExpenseManager';
import { OfflineReportsDashboard } from './components/reports/OfflineReportsDashboard';
import { BackupRestoreManager } from './components/backup/BackupRestoreManager';
import { OwnerSettingsModal } from './components/settings/OwnerSettingsModal';
import { OfflineTestSuite } from './components/tests/OfflineTestSuite';

// Preserved Public B2B Website & Storefront Modules
import { HeroAndFeatures } from './components/public/HeroAndFeatures';
import { CatalogueSection } from './components/public/CatalogueSection';
import { AboutSection } from './components/public/AboutSection';
import { AnnouncementsSection } from './components/public/AnnouncementsSection';
import { FuturePlansSection } from './components/public/FuturePlansSection';
import { ContactSection } from './components/public/ContactSection';
import { CartModal } from './components/public/CartModal';
import { AuthModal } from './components/public/AuthModal';
import { DashboardLayout } from './components/dashboard/DashboardLayout';

import {
  CreditCard,
  Menu,
  Sparkles,
  Download,
  Settings,
  Lock,
  Package,
  Layers,
  Boxes,
  Truck,
  Receipt,
  Users,
  Building2,
  Wallet,
  TrendingUp,
  HardDriveDownload,
  CheckCircle,
  Globe,
  LayoutDashboard,
} from 'lucide-react';

const ClothingWholesaleApp: React.FC = () => {
  const { isAppLocked, settings, lockApp, isOnline } = useClothingWholesale();

  // Active Tab: dashboard, pos, sales, fashion, products, categories, inventory, purchases, customers, suppliers, expenses, reports, backup, tests, public_storefront
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isProjectExportOpen, setIsProjectExportOpen] = useState(false);

  // Preserved public storefront sub-view state
  const [publicView, setPublicView] = useState<string>('home');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);

  // If local owner PIN lock is active, show lock screen
  if (isAppLocked) {
    return <AppLockScreen />;
  }

  // Tab metadata for top header title & icon
  const getTabHeader = () => {
    switch (activeTab) {
      case 'dashboard':
        return { title: 'Executive Operations Dashboard', icon: LayoutDashboard, subtitle: 'Real-time wholesale cash sales, inventory valuation, and stock alerts' };
      case 'pos':
        return { title: 'POS Cash Billing Counter', icon: CreditCard, subtitle: 'Instant barcode scan, variant picker, and offline receipt printing' };
      case 'sales':
        return { title: 'Sales History & Invoices', icon: Receipt, subtitle: 'Cash receipts, invoice reprints, and audited sale returns' };
      case 'fashion':
        return { title: 'Garments, Textiles & Fashion Collection', icon: Sparkles, subtitle: 'Western tailoring, bridal lehengas, silk sarees, gowns, and textile yardage' };
      case 'products':
        return { title: 'Products & Multi-Variant Catalog', icon: Package, subtitle: 'Multi-size & multi-color clothing items, SKUs, and barcode tracking' };
      case 'categories':
        return { title: 'Garment & Fabric Categories', icon: Layers, subtitle: 'Hierarchy organization across Western, Ethnic, Dresses, Men\'s Traditional & Textiles' };
      case 'inventory':
        return { title: 'Inventory Stock Matrix', icon: Boxes, subtitle: 'Variant-level stock levels, quick adjustments, and audit trail movements' };
      case 'purchases':
        return { title: 'Purchases & Mill Stock Receiving', icon: Truck, subtitle: 'Inbound consignment logging, supplier bills, and cost price updates' };
      case 'customers':
        return { title: 'Wholesale Customers & Retailers', icon: Users, subtitle: 'Customer directory, contact numbers, PAN/VAT, and purchase history' };
      case 'suppliers':
        return { title: 'Suppliers, Mills & Production Houses', icon: Building2, subtitle: 'Textile mills, knitwear manufacturers, and procurement contacts' };
      case 'expenses':
        return { title: 'Shop & Warehouse Cash Expenses', icon: Wallet, subtitle: 'Rent, freight, packaging, tea/meals, utilities, and daily vouchers' };
      case 'reports':
        return { title: 'Reports, Gross Margins & Profitability', icon: TrendingUp, subtitle: 'COGS calculations, net margins, category breakdown, and top sellers' };
      case 'backup':
        return { title: 'Backup, Restore & Data Portability', icon: HardDriveDownload, subtitle: '100% offline IndexedDB export, JSON restore, and CSV spreadsheets' };
      case 'tests':
        return { title: 'System Health & Integrity Self-Tests', icon: CheckCircle, subtitle: 'Automated offline database tests, schema validation, and storage checks' };
      case 'public_storefront':
        return { title: 'Public B2B Showroom & Storefront View', icon: Globe, subtitle: 'Showroom preview, buyer catalogue, and multi-user portal demonstration' };
      default:
        return { title: 'Wholesale Management System', icon: LayoutDashboard, subtitle: settings.businessName };
    }
  };

  const currentTabMeta = getTabHeader();
  const HeaderIcon = currentTabMeta.icon;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex font-sans antialiased">
      {/* 1. Left Compact & Collapsible ERP Sidebar */}
      <AppSidebar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenProjectExport={() => setIsProjectExportOpen(true)}
        isMobileOpen={isMobileNavOpen}
        onCloseMobile={() => setIsMobileNavOpen(false)}
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
      />

      {/* 2. Main Workspace Layout */}
      <div
        className={`flex-1 flex flex-col min-w-0 transition-all duration-200 ${
          isSidebarCollapsed ? 'md:pl-18' : 'md:pl-60'
        }`}
      >
        {/* Offline & PWA Installation Status Banner */}
        <OfflineStatusBanner />

        {/* Top Header Bar */}
        <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-2xs">
          <div className="px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
            {/* Left: Mobile Toggle & Tab Title */}
            <div className="flex items-center gap-3 min-w-0">
              <button
                onClick={() => setIsMobileNavOpen(true)}
                className="p-2 -ml-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 md:hidden cursor-pointer"
                aria-label="Open navigation drawer"
              >
                <Menu className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 hidden sm:flex">
                  <HeaderIcon className="w-4 h-4 text-slate-700" />
                </div>
                <div className="min-w-0">
                  <h2 className="text-sm sm:text-base font-bold text-slate-900 truncate leading-tight">
                    {currentTabMeta.title}
                  </h2>
                  <p className="text-[11px] text-slate-500 truncate hidden md:block">
                    {currentTabMeta.subtitle}
                  </p>
                </div>
              </div>
            </div>

            {/* Right: Quick Action Buttons */}
            <div className="flex items-center gap-2 shrink-0">
              {/* Quick POS Shortcut */}
              {activeTab !== 'pos' && (
                <button
                  onClick={() => setActiveTab('pos')}
                  className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition-colors shadow-2xs cursor-pointer"
                  title="Open fast POS Billing Counter"
                >
                  <CreditCard className="w-3.5 h-3.5 text-amber-400" />
                  <span>POS Counter</span>
                </button>
              )}

              {/* Quick Fashion Collection Shortcut */}
              {activeTab !== 'fashion' && (
                <button
                  onClick={() => setActiveTab('fashion')}
                  className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-bold text-xs rounded-xl transition-colors cursor-pointer"
                  title="Browse Fashion & Textiles Collection"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  <span>Fashion Collection</span>
                </button>
              )}

              {/* Download Project Source (.zip) */}
              <button
                onClick={() => setIsProjectExportOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl transition-colors shadow-2xs cursor-pointer"
                title="Download entire project source in a file"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Project Source (.zip)</span>
                <span className="sm:hidden text-[11px] font-mono">.ZIP</span>
              </button>

              {/* Optional Screen Lock Trigger */}
              {settings.ownerPinHash && (
                <button
                  onClick={lockApp}
                  className="p-2 text-slate-600 hover:text-rose-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                  title="Lock terminal now"
                  aria-label="Lock terminal"
                >
                  <Lock className="w-4 h-4" />
                </button>
              )}

              {/* Settings Trigger */}
              <button
                onClick={() => setIsSettingsOpen(true)}
                className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                title="Business Settings & Local PIN Lock"
                aria-label="Settings"
              >
                <Settings className="w-4 h-4" />
              </button>
            </div>
          </div>
        </header>

        {/* 3. Main Workspace Router */}
        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6">
          {activeTab === 'dashboard' && <ExecutiveDashboard onNavigate={setActiveTab} />}
          {activeTab === 'pos' && <CashBillingPos />}
          {activeTab === 'sales' && <SalesHistoryManager />}
          {activeTab === 'fashion' && (
            <FashionCollectionShowcase
              onOpenPos={() => setActiveTab('pos')}
              onOpenAddProduct={() => setActiveTab('products')}
            />
          )}
          {activeTab === 'products' && <ProductCatalogManager />}
          {activeTab === 'categories' && (
            <CategoryManager onSelectCategoryFilter={() => setActiveTab('products')} />
          )}
          {activeTab === 'inventory' && <InventoryStockMatrix />}
          {activeTab === 'purchases' && <PurchasesAndStockManager />}
          {activeTab === 'customers' && (
            <CustomerManager onStartSaleForCustomer={() => setActiveTab('pos')} />
          )}
          {activeTab === 'suppliers' && (
            <SupplierManager onStartPurchaseForSupplier={() => setActiveTab('purchases')} />
          )}
          {activeTab === 'expenses' && <ExpenseManager />}
          {activeTab === 'reports' && <OfflineReportsDashboard />}
          {activeTab === 'backup' && <BackupRestoreManager />}
          {activeTab === 'tests' && <OfflineTestSuite />}

          {/* Preserved Public B2B Showroom & Storefront View */}
          {activeTab === 'public_storefront' && (
            <div className="space-y-6">
              <div className="bg-slate-900 text-white p-4 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 text-xs">
                <div>
                  <span className="text-amber-400 font-bold block">PUBLIC STOREFRONT PREVIEW</span>
                  <span className="text-slate-300">Preserved B2B catalogue showcase and customer portal.</span>
                </div>
                <button
                  onClick={() => setActiveTab('pos')}
                  className="px-3 py-1.5 bg-amber-500 text-slate-950 font-bold rounded-lg hover:bg-amber-400 cursor-pointer"
                >
                  Back to POS Counter &rarr;
                </button>
              </div>

              <div className="flex gap-2 border-b border-slate-200 pb-2 text-xs font-semibold overflow-x-auto">
                {['home', 'catalogue', 'about', 'announcements', 'plans', 'contact', 'dashboard'].map((v) => (
                  <button
                    key={v}
                    onClick={() => setPublicView(v)}
                    className={`px-3 py-1.5 rounded-lg capitalize whitespace-nowrap cursor-pointer ${
                      publicView === v ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {v.replace('_', ' ')}
                  </button>
                ))}
              </div>

              {publicView === 'home' && (
                <HeroAndFeatures
                  onExploreCatalogue={() => setPublicView('catalogue')}
                  onOpenRegister={() => setIsAuthOpen(true)}
                />
              )}
              {publicView === 'catalogue' && <CatalogueSection />}
              {publicView === 'about' && <AboutSection />}
              {publicView === 'announcements' && <AnnouncementsSection />}
              {publicView === 'plans' && <FuturePlansSection />}
              {publicView === 'contact' && <ContactSection />}
              {publicView === 'dashboard' && <DashboardLayout />}
            </div>
          )}
        </main>

        {/* 4. Footer */}
        <footer className="bg-white border-t border-slate-200 text-slate-500 text-xs mt-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-0.5 text-center sm:text-left">
              <div className="text-slate-900 font-bold">
                {settings.businessName} · {settings.tradingName}
              </div>
              <div className="text-[11px] text-slate-500 font-mono">
                PAN/VAT: {settings.panVatNumber} · {settings.address} · Tel: {settings.phone}
              </div>
              <div className="text-[10px] text-slate-400">
                100% Offline-First IndexedDB Engine · Single-Operator Clothing & Textiles Wholesale Terminal
              </div>
            </div>

            <div className="flex items-center gap-3 text-xs">
              <button
                onClick={() => setActiveTab('tests')}
                className="text-amber-600 hover:text-amber-700 font-semibold cursor-pointer"
              >
                Integrity Tests
              </button>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <button
                onClick={() => setIsSettingsOpen(true)}
                className="hover:text-slate-900 cursor-pointer"
              >
                Settings
              </button>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <button
                onClick={() => setActiveTab('backup')}
                className="hover:text-slate-900 cursor-pointer"
              >
                Backup JSON
              </button>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <button
                onClick={() => setIsProjectExportOpen(true)}
                className="text-amber-600 hover:text-amber-700 font-bold flex items-center gap-1 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Project Files (.zip)</span>
              </button>
            </div>
          </div>
        </footer>

        {/* 5. Modals */}
        <ProjectExportModal
          isOpen={isProjectExportOpen}
          onClose={() => setIsProjectExportOpen(false)}
        />

        <OwnerSettingsModal
          isOpen={isSettingsOpen}
          onClose={() => setIsSettingsOpen(false)}
        />

        {/* Preserved Cart & Auth Modals for Public Showroom */}
        <CartModal
          isOpen={isCartOpen}
          onClose={() => setIsCartOpen(false)}
          onOpenAuth={() => {
            setIsCartOpen(false);
            setIsAuthOpen(true);
          }}
        />
        <AuthModal
          isOpen={isAuthOpen}
          onClose={() => setIsAuthOpen(false)}
        />
      </div>
    </div>
  );
};

export default function App() {
  return (
    <ClothingWholesaleProvider>
      <WholesaleProvider>
        <ClothingWholesaleApp />
      </WholesaleProvider>
    </ClothingWholesaleProvider>
  );
}
